package com.digitalads.android;

import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.TextView;

import com.digitalads.android.fragments.HomeFragment;
import com.digitalads.android.fragments.OffersFragment;

public class HomeActivity extends AppCompatActivity implements HomeFragment.OnFragmentInteractionListener
, OffersFragment.OnFragmentInteractionListener {

    private TextView mTextMessage;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    loadFragment(HomeFragment.class);
                    return true;
                case R.id.navigation_dashboard:
                   // loadFragment(PincodeAndStateSelection.class);
                    return true;
                case R.id.navigation_news:
                    mTextMessage.setText(R.string.title_notifications);
                    return true;
                case R.id.navigation_offers:
                    loadFragment(OffersFragment.class);
                    return true;
            }
            return false;
        }
    };

    private void loadFragment(Class fragmentClass) {
        Fragment fragment = null;
        try {
            fragment = (Fragment) fragmentClass.newInstance();
        } catch (Exception e) {
            e.printStackTrace();
        }
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.flContent, fragment).commit();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_home);

        mTextMessage = (TextView) findViewById(R.id.message);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        loadFragment(HomeFragment.class);
    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }

}
