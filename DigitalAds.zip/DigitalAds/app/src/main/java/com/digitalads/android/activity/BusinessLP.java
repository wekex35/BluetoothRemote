package com.digitalads.android.activity;

import android.content.ClipData;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.basgeekball.awesomevalidation.utility.RegexTemplate;
import com.digitalads.android.HomeActivity;
import com.digitalads.android.adapter.MutliSelectAdapter;
import com.digitalads.android.R;
import com.digitalads.android.model.UserModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static com.digitalads.android.utils.Constants.BUSINESSLISTING;
import static com.digitalads.android.utils.Constants.BUSINESSPROFILE;
import static com.digitalads.android.utils.Constants.CATEGORIES;
import static com.digitalads.android.utils.Constants.DETAILS;
import static com.digitalads.android.utils.Constants.EMAIL;
import static com.digitalads.android.utils.Constants.IMAGES;
import static com.digitalads.android.utils.Constants.KEYWORDS;
import static com.digitalads.android.utils.Constants.NAME;
import static com.digitalads.android.utils.Constants.PHONE;
import static com.digitalads.android.utils.Constants.PICK_IMAGE_MUTIPLE;
import static com.digitalads.android.utils.Constants.PICK_IMAGE_REQUEST;
import static com.digitalads.android.utils.Constants.PROFILE_PIC;
import static com.digitalads.android.utils.Constants.SUB_CATEGORIES;
import static com.digitalads.android.utils.Constants.UUID;
import static com.digitalads.android.utils.Constants.WEBSITE;
import static com.digitalads.android.utils.Constants.baseurl;
import static com.digitalads.android.utils.Utils.getImageString;
import static com.digitalads.android.utils.Utils.goneVisibility;
import static com.digitalads.android.utils.Utils.saveContent;
import static com.digitalads.android.utils.Utils.stringToJsonArray;
import static com.digitalads.android.utils.Utils.toggleVisibility;

public class BusinessLP extends AppCompatActivity {
    public static ArrayList<String> keywordsList = new ArrayList<>();
    String TAG = "BusinessLP";
    TextView t_profileButton,t_listingButton;
    LinearLayout businessListing,businessProfiles;
    Bitmap bitmap;
    ImageView _logo;
    String logo;
    JSONArray images;
    LinearLayout imageHolder;
    ArrayList<String> imagesEncodedList ;
    EditText _email,_phone,_web_url,_details,
            _keywords,_businessname;
    Spinner _sub_Category;
    Spinner _Category;
    UserModel user;
    private String upimages;
    Boolean isDonelisting = false;
    Boolean isDoneprofile = false;
    int progress = 0;
    RelativeLayout progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_business_lp);
        imagesEncodedList = new ArrayList<String>();
        initView();
    }

    private void initView() {
         user = new UserModel(this);
        imageHolder = findViewById(R.id.imageHplder);
        businessListing = findViewById(R.id.businessListing);
        businessProfiles = findViewById(R.id.businessProfiles);
        _logo = findViewById(R.id.logo);
        progressBar = findViewById(R.id.progressBar);

        //Business Listing
        _keywords =findViewById(R.id.keywords);
        _businessname =findViewById(R.id.name);
        _Category = findViewById(R.id.category);
        _sub_Category = findViewById(R.id.sub_category);
        t_profileButton = findViewById(R.id.profileButton);


        //Business Profile
        _email = findViewById(R.id.email);
        _phone = findViewById(R.id.phone);
        _web_url = findViewById(R.id.web_url);
        _details = findViewById(R.id.details);
        t_listingButton = findViewById(R.id.listingButton);

        addCategories();
    }

    private void addCategories() {

        String url = baseurl+"catall";
                RequestQueue queue = Volley.newRequestQueue(BusinessLP.this);
                StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                // response
                                Log.d(TAG, " onResponse: " + response);
                                ArrayList<String> categoryList = new ArrayList<>();
                                JSONArray pinArrays = stringToJsonArray(response);

                                for (int i =0;i <  pinArrays.length();i++){

                                    try {
                                        JSONObject  category = pinArrays.getJSONObject(i);
                                       // pincodeDetails.add(pincodes);

                                        categoryList.add(category.getString("categories"));


                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }

                                }
                                Log.d(TAG, "onResponse: "+categoryList.toString());
                                ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(
                                        BusinessLP.this,android.R.layout.simple_spinner_item, categoryList);
                                spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); // The drop down vieww
                                _Category.setAdapter(spinnerArrayAdapter);
                                _Category.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                    @Override
                                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                                        ((TextView) parent.getChildAt(0)).setTextColor(getResources().getColor(R.color.white));
                                        keyWords(_Category.getSelectedItem().toString());
                                        //Log.d(TAG, "onItemSelected: "+textView.getText().toString());
                                    }

                                    @Override
                                    public void onNothingSelected(AdapterView<?> parent) {

                                    }
                                });
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                // error
                                Log.d(TAG, error.toString() + " onErrorResponse: " + error.getMessage());
                                //Log.d(error.toString()+" Error.Response ", error.getMessage());
                                //Log.d(error.toString()+" Error.Response ", error.getMessage());
                            }
                        }
                );


                queue.add(stringRequest);

    }

    public void clearkeywords(){
        keywordsList.clear();
        _keywords.getText().clear();
    }

    public void keyWords(String selectedItem){
        clearkeywords();
        String url = baseurl+"subcat/"+selectedItem;
        RequestQueue queue = Volley.newRequestQueue(BusinessLP.this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // response
                        Log.d(TAG, " onResponse: " + response);
                        ArrayList<String> subCategoriesList = new ArrayList<>();
                        JSONArray subCategories = stringToJsonArray(response);
                        subCategoriesList.add("Related Keywords");

                        for (int i =0;i <  subCategories.length();i++){

                            try {
                                JSONObject  category = subCategories.getJSONObject(i);
                                // pincodeDetails.add(pincodes);

                                subCategoriesList.add(category.getString("sub_categories"));


                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                        Log.d(TAG, "onResponse: "+subCategoriesList.toString());


                        MutliSelectAdapter mutliSelectAdapter = new MutliSelectAdapter(BusinessLP.this,subCategoriesList);

                        _sub_Category.setAdapter(mutliSelectAdapter);

                        _sub_Category.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                ((TextView) parent.getChildAt(0)).setTextColor(getResources().getColor(R.color.white));

                                 //Log.d(TAG, "onItemSelected: "+textView.getText().toString());
                            }

                            @Override
                            public void onNothingSelected(AdapterView<?> parent) {

                            }
                        });
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // error
                        Log.d(TAG, error.toString() + " onErrorResponse: " + error.getMessage());
                        //Log.d(error.toString()+" Error.Response ", error.getMessage());
                        //Log.d(error.toString()+" Error.Response ", error.getMessage());
                    }
                }
        );


        queue.add(stringRequest);

        //
    }

    public void loadImage(View view) {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_PICK);
        startActivityForResult(Intent.createChooser(intent, "Select Image"), PICK_IMAGE_REQUEST);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri filePath = data.getData();

            try {
                //getting image from gallery
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                //Setting image to ImageView
                _logo.setImageBitmap(bitmap);
                logo = getImageString(bitmap);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (requestCode == PICK_IMAGE_MUTIPLE && resultCode == RESULT_OK && data != null) {
            String[] filePathColumn = { MediaStore.Images.Media.DATA };
            String imageEncoded;
            if (data.getClipData() != null) {
                ClipData mClipData = data.getClipData();
                ArrayList<Uri> mArrayUri = new ArrayList<Uri>();
                for (int i = 0; i < mClipData.getItemCount(); i++) {

                    ClipData.Item item = mClipData.getItemAt(i);
                    Uri filePath = item.getUri();
                    try {
                        //getting image from gallery
                        bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                        //Setting image to ImageView
                        View view = getLayoutInflater().inflate(R.layout.business_icon,null,false);
                        ImageView imageView = view.findViewById(R.id.imageViewItem);
                        imageView.setImageBitmap(bitmap);
                        imageHolder.addView(view);
                        imageEncoded = getImageString(bitmap);
                        imagesEncodedList.add(imageEncoded);
                        if (i==5){
                            Toast.makeText(this, R.string.maximum+" "+String.valueOf(i), Toast.LENGTH_SHORT).show();
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }
                Log.v("LOG_TAG", "Selected Images" + mArrayUri.size());
            }
            else if(data.getData()!=null){

                Uri filePath = data.getData();
                try {
                    //getting image from gallery
                    bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                    //Setting image to ImageView
                    View view = getLayoutInflater().inflate(R.layout.post_card_headline,null,false);
                    ImageView imageView = view.findViewById(R.id.imageViewItem);
                    imageView.setImageBitmap(bitmap);
                    imageHolder.addView(imageView);
                    imageEncoded = getImageString(bitmap);
                    imagesEncodedList.add(imageEncoded);

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }


            images = new JSONArray(imagesEncodedList);
            Log.d(TAG, "onActivityResult: "+images.length());
        }
    }

    public void doneListing(View view) {
        AwesomeValidation awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);

        awesomeValidation.addValidation(this, R.id.name, RegexTemplate.NOT_EMPTY, R.string.userid);
        awesomeValidation.addValidation(this, R.id.keywords, RegexTemplate.NOT_EMPTY, R.string.userid);

        if (awesomeValidation.validate()){
            toggleVisibility(progressBar);
        RequestQueue queue = Volley.newRequestQueue(this);
        //  String url ="http://192.168.56.1/digitalAds/homepage.json";
        // String url ="http://192.168.56.1:8000/api/v1/list";
        String url = baseurl + "bl";
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("data", "sssssshello");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // response
                        Log.d(TAG, " onResponse: " + response);
                        toggleVisibility(progressBar);
                        saveContent(BusinessLP.this, BUSINESSLISTING, response);
                        isDonelisting = true;
                        if (isDoneprofile)
                            startActivity(new Intent(BusinessLP.this, HomeActivity.class));
                        else {
                            goneVisibility(businessListing);
                            goneVisibility(t_profileButton);
                            goneVisibility(t_listingButton);
                            businessProfiles.setVisibility(View.VISIBLE);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        toggleVisibility(progressBar);
                        // error
                        Log.d(TAG, error.toString() + " onErrorResponse: " + error.getMessage());
                        //Log.d(error.toString()+" Error.Response ", error.getMessage());
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put(UUID, user.getUUID());
                params.put(NAME, _businessname.getText().toString());
                params.put(PROFILE_PIC, logo);
                params.put(CATEGORIES, _Category.getSelectedItem().toString());
                params.put(SUB_CATEGORIES, keywordsList.get((int) keywordsList.size() / 2));
                params.put(KEYWORDS, _keywords.getText().toString());


                return params;
            }
        };

        queue.add(stringRequest);

    }

        }

    public void doneProfiles(View view) {

        AwesomeValidation awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);

        //awesomeValidation.addValidation(this, R.id.email, RegexTemplate.NOT_EMPTY, R.string.userid);
        awesomeValidation.addValidation(this, R.id.phone, RegexTemplate.NOT_EMPTY, R.string.userid);
        awesomeValidation.addValidation(this, R.id.details, RegexTemplate.NOT_EMPTY, R.string.userid);
        if ( images==null){
            Toast.makeText(this, "", Toast.LENGTH_SHORT).show();
            upimages = "[]";

            return;
        }else {
            upimages = images.toString();
        }


        if (awesomeValidation.validate()) {
            toggleVisibility(progressBar);
            RequestQueue queue = Volley.newRequestQueue(this);
            //  String url ="http://192.168.56.1/digitalAds/homepage.json";
            // String url ="http://192.168.56.1:8000/api/v1/list";
            String url = baseurl + "bp";
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("data", "sssssshello");
            } catch (JSONException e) {
                e.printStackTrace();
            }
            StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            // response
                            Log.d(TAG, " onResponse: " + response);
                            toggleVisibility(progressBar);
                            saveContent(BusinessLP.this, BUSINESSPROFILE, response);
                            //startActivity(new Intent(RegLoginActivity.this, addressActivity.class));
                            isDoneprofile = true;
                            if (isDonelisting)
                                startActivity(new Intent(BusinessLP.this, HomeActivity.class));
                            else {
                                goneVisibility(t_profileButton);
                                goneVisibility(businessProfiles);
                                goneVisibility(t_listingButton);
                                businessListing.setVisibility(View.VISIBLE);
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            toggleVisibility(progressBar);
                            // error
                            Log.d(TAG, error.toString() + " onErrorResponse: " + error.getMessage());
                            //Log.d(error.toString()+" Error.Response ", error.getMessage());
                        }
                    }
            ) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put(UUID, user.getUUID());
                    params.put(EMAIL, _email.getText().toString());
                    params.put(PHONE, _phone.getText().toString());
                    params.put(WEBSITE, _web_url.getText().toString());
                    params.put(IMAGES, upimages);
                    params.put(DETAILS, _details.getText().toString());

                    return params;
                }
            };

            queue.add(stringRequest);
        }

    }

    public void multiSelect(View view) {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.setAction(Intent.ACTION_PICK);
        startActivityForResult(Intent.createChooser(intent, "Select Image"), PICK_IMAGE_MUTIPLE);
    }

    public void showListing(View view) {
        toggleVisibility(businessListing);
        toggleVisibility(t_profileButton);
        toggleVisibility(businessProfiles);
        toggleVisibility(t_listingButton);
    }

    public void showProfile(View view) {
        toggleVisibility(businessListing);
        toggleVisibility(t_profileButton);
        toggleVisibility(businessProfiles);
        toggleVisibility(t_listingButton);
    }

    public void showList(View view) {
        _sub_Category.performClick();
    }

    public void setItemTokeywords() {
        _keywords.setText(keywordsList.toString().replace("[","").replace("]",""));
    }
}
