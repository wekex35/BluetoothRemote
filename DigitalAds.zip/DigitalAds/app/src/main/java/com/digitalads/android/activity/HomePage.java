package com.digitalads.android.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.View;
import android.support.v4.view.GravityCompat;
import android.support.v7.app.ActionBarDrawerToggle;
import android.view.MenuItem;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.widget.ImageView;
import android.widget.TextView;

import com.digitalads.android.R;
import com.digitalads.android.fragments.HomeFragment;
import com.digitalads.android.fragments.OffersFragment;
import com.digitalads.android.model.UserModel;
import com.digitalads.android.views.MyTextViewRegular;

import static com.digitalads.android.utils.Constants.REQUEST_INVITE;
import static com.digitalads.android.utils.Constants.WEBURL;
import static com.digitalads.android.utils.Utils.webview;

public class HomePage extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener, HomeFragment.OnFragmentInteractionListener
, OffersFragment.OnFragmentInteractionListener {

        private TextView mTextMessage;

        private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
                = new BottomNavigationView.OnNavigationItemSelectedListener() {

            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.navigation_home:
                        loadFragment(HomeFragment.class);
                        return true;
                    case R.id.navigation_dashboard:
                        // loadFragment(PincodeAndStateSelection.class);
                        return true;
                    case R.id.navigation_news:
                       // mTextMessage.setText(R.string.title_notifications);
                        return true;
                    case R.id.navigation_offers:
                        loadFragment(OffersFragment.class);
                        return true;
                }
                return false;
            }
        };

        private void loadFragment(Class fragmentClass) {
            Fragment fragment = null;
            try {
                fragment = (Fragment) fragmentClass.newInstance();
            } catch (Exception e) {
                e.printStackTrace();
            }
            FragmentManager fragmentManager = getSupportFragmentManager();
            fragmentManager.beginTransaction().replace(R.id.flContent, fragment).commit();
        }


        @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        mTextMessage = (TextView) findViewById(R.id.message);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        loadFragment(HomeFragment.class);

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
        View header=navigationView.getHeaderView(0);
            initView();
        navHead(header);

    }

    private ImageView profilePic;
    private MyTextViewRegular email,profilename;
    private UserModel userModel;

    private void initView() {
        userModel = new UserModel(this);

        //navHead();

    }

    private void navHead(View header) {
        profilename = header.findViewById(R.id.profileName);
        email = header.findViewById(R.id.email);
        profilePic = header.findViewById(R.id.profilePic);
        profilename.setText(userModel.getname());
        email.setText(userModel.getEmail());
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main2, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {

            return true;
        }
        if (id == R.id.search) {

            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();


        if (id == R.id.nav_home) {
            // Handle the camera action
        } else if (id == R.id.nav_gallery) {

        } else if (id == R.id.nav_slideshow) {

        } else if (id == R.id.nav_tools) {

        }else if (id == R.id.nav_account) {
            startActivity(new Intent(HomePage.this,ProfileView.class));
        } else if (id == R.id.nav_share) {
            share();
        } else if (id == R.id.nav_event) {
            startActivity(new Intent(HomePage.this,PostNews.class));
        } else if (id == R.id.nav_offers) {
            startActivity(new Intent(HomePage.this,PostAds.class));
        } else if (id == R.id.nav_postNews) {
            startActivity(new Intent(HomePage.this,PostNews.class));
        }else if (id == R.id.nav_terms) {
            webview(HomePage.this,"terms");
        }else if (id == R.id.nav_policy) {
            webview(HomePage.this,"privacy");
        }else if (id == R.id.nav_copy) {
            webview(HomePage.this,"copyright");
        }else if (id == R.id.nav_about) {
            webview(HomePage.this,"about");
        }else if (id == R.id.nav_contact) {
            webview(HomePage.this,"contact");
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
    @Override
    public void onFragmentInteraction(Uri uri) {

    }
    private void share() {
        final String appPackageName = getPackageName();
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT,
                "Hey check out tonFragmentInteractionhis app at: https://play.google.com/store/apps/details?id=" + appPackageName);
        sendIntent.setType("text/plain");
        startActivityForResult(sendIntent,REQUEST_INVITE);
    }

    public void launch(String appPackageName){
        //final String appPackageName = getPackageName(); // getPackageName() from Context or Activity object
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://" + appPackageName)));
        } catch (android.content.ActivityNotFoundException anfe) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/" + appPackageName)));
        }
    }
}
