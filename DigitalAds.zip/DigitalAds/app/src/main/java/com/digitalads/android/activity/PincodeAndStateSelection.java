package com.digitalads.android.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.digitalads.android.R;
import com.digitalads.android.views.MyTextViewRegular;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import static com.digitalads.android.utils.Constants.STATE;
import static com.digitalads.android.utils.Constants.baseurl;
import static com.digitalads.android.utils.Utils.goneVisibility;
import static com.digitalads.android.utils.Utils.loadFileAsset;
import static com.digitalads.android.utils.Utils.stringToJsonArray;
import static com.digitalads.android.utils.Utils.toggleVisibility;


public class PincodeAndStateSelection extends AppCompatActivity {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;
    private int adslocCode;

    private String TAG = "PincodeAndStateSelection";
    private Spinner s_state,s_district,s_taluka,s_regionname,_postOffice,Sarea;
    private String statename,districtname,regionname,taluk;
    private String jsonData;
    private AutoCompleteTextView _businessName,_address,_building,_street,_landmark
            ,_pincode;
    private MyTextViewRegular _state,_district,_taluka,_city,_latLong,_area,selectState;
    private ArrayList<JSONObject> pincodeDetails;
    private LinearLayout L_deliveryAdds,L_poffice,L_pinDetails,L_manual,L_getAreaLayout,L_bypin;
    private ImageView searchpin,expand_button;
    private Button getarea;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pincode_and_state_selection);
        adslocCode = getIntent().getIntExtra("adslocCode",0);





        jsonData = loadFileAsset(PincodeAndStateSelection.this,"support/state");
        s_state = findViewById(R.id.Sstate);
        s_district = findViewById(R.id.Sdistrict);
        s_taluka = findViewById(R.id.Staluka);
        s_regionname = findViewById(R.id.Sregion);
        Sarea = findViewById(R.id.Sarea);
        L_manual = findViewById(R.id.manual);
        selectState = findViewById(R.id.selectState);
        expand_button = findViewById(R.id.expand_button);
        getarea = findViewById(R.id.getarea);


        selectState.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: ");
                L_poffice.setVisibility(View.GONE);
                L_pinDetails.setVisibility(View.GONE);
                if(L_manual.getVisibility()== View.VISIBLE) {
                    expand_button.setImageResource(R.drawable.ic_expand_more_black_24dp);
                    Sarea.setVisibility(View.VISIBLE);
                }
                else {
                    expand_button.setImageResource(R.drawable.ic_expand_less_black_24dp);
                    Sarea.setVisibility(View.VISIBLE);
                }
                toggleVisibility(L_manual);
            }
        });

        getarea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getArea(v);
            }
        });


        //short Address
        _pincode = findViewById(R.id.pincode);
        _state = findViewById(R.id.state);
        _district = findViewById(R.id.district);
        _taluka = findViewById(R.id.taluka);
        _city = findViewById(R.id.city);
        //_area = findViewById(R.id.area);
        L_poffice = findViewById(R.id.poffice);
        L_pinDetails = findViewById(R.id.pinDetails);
        L_getAreaLayout = findViewById(R.id.getAreaLayout);
        L_bypin = findViewById(R.id.bypin);
        _postOffice = findViewById(R.id.postOffice);
        searchpin = findViewById(R.id.searchpin);


        populateSpinner(s_state,"statename");
        Log.d(TAG, "onCreateView: "+jsonData);
        init();
        
    }



    

    private void init() {
        if (adslocCode==0||adslocCode==1)
            L_bypin.setVisibility(View.VISIBLE);
        searchpin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goneVisibility(L_manual);
                Log.d(TAG, "onFocusChange: ");
                pincodeDetails = new ArrayList<>();

                    if (_pincode.length() != 6)
                        Toast.makeText(PincodeAndStateSelection.this, "Pin", Toast.LENGTH_SHORT).show();
                    else {
                        String url = "http://192.168.252.2/DigiApi/public/api/v1/getdata/"+_pincode.getText().toString();
                        RequestQueue queue = Volley.newRequestQueue(PincodeAndStateSelection.this);
                        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                                new Response.Listener<String>() {
                                    @Override
                                    public void onResponse(String response) {
                                        // response
                                        Log.d(TAG, " onResponse: " + response);
                                        ArrayList<String> po = new ArrayList<>();
                                        JSONArray pinArrays = stringToJsonArray(response);

                                        for (int i =0;i <  pinArrays.length();i++){

                                            try {
                                                JSONObject  pincodes = pinArrays.getJSONObject(i);
                                                pincodeDetails.add(pincodes);

                                                po.add(pincodes.getString("officename")
                                                        .replace("B.O","")
                                                        .replace("S.O","")
                                                        .replace("H.O","")
                                                );


                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            }

                                        }
                                        L_poffice.setVisibility(View.VISIBLE);
                                        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(PincodeAndStateSelection.this,android.R.layout.simple_spinner_item, po);
                                        spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); // The drop down vieww
                                        _postOffice.setAdapter(spinnerArrayAdapter);
                                    }
                                },
                                new Response.ErrorListener() {
                                    @Override
                                    public void onErrorResponse(VolleyError error) {
                                        // error
                                        Log.d(TAG, error.toString() + " onErrorResponse: " + error.getMessage());
                                        //Log.d(error.toString()+" Error.Response ", error.getMessage());
                                        //Log.d(error.toString()+" Error.Response ", error.getMessage());
                                    }
                                }
                        );

                        queue.add(stringRequest);
                    }

                _postOffice.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        JSONObject selctedOfficeObject = pincodeDetails.get(position);
                        L_pinDetails.setVisibility(View.VISIBLE);
                        try {
                            _state.setText(selctedOfficeObject.getString("statename"));
                            _taluka.setText(selctedOfficeObject.getString("Taluk"));
                            _district.setText(selctedOfficeObject.getString("Districtname"));
                            _city.setText(selctedOfficeObject.getString("regionname"));
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });
            }

        });
    }

    private void populateSpinner(final Spinner spinner, final String name) {
        Sarea.setVisibility(View.GONE);
        ArrayList<String> arrayList = new ArrayList<>();
        JSONArray pinArrays = stringToJsonArray(jsonData);

        for (int i =0;i <  pinArrays.length();i++){

            try {
                JSONObject pincodes = pinArrays.getJSONObject(i);
                String val = "";
                switch (name){
                    case "statename" :

                         val = pincodes.getString(name);
                        break;
                    case "regionname" :
                        if (pincodes.getString("statename").equals(statename))
                            val = pincodes.getString(name);

                        break;
                    case "districtname" :
                        if (pincodes.getString("statename").equals(statename)&&pincodes.getString("regionname").equals(regionname))
                            val = pincodes.getString(name);

                        break;

                    case "Taluk":
                        if (pincodes.getString("statename").equals(statename)
                                &&pincodes.getString("districtname").equals(districtname)
                                &&pincodes.getString("regionname").equals(regionname))

                            val = pincodes.getString(name);

                        break;

                }

                if (!arrayList.contains(val)&&!val.equals("")){
                    arrayList.add(val);
                }


            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
        //L_poffice.setVisibility(View.VISIBLE);
        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(PincodeAndStateSelection.this,android.R.layout.simple_spinner_item, arrayList);
        spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); // The drop down vieww
        spinner.setAdapter(spinnerArrayAdapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (name){
                    case "statename" :
                        statename = spinner.getSelectedItem().toString();
                        if (adslocCode==0||adslocCode==1||adslocCode==7||adslocCode==5||adslocCode==3) {
                            populateSpinner(s_regionname, "regionname");
                            s_regionname.setVisibility(View.VISIBLE);

                        }
                        break;
                    case "regionname" :
                        regionname = spinner.getSelectedItem().toString();
                        if (adslocCode==0||adslocCode==1||adslocCode==5||adslocCode==3) {
                            populateSpinner(s_district, "districtname");
                            s_district.setVisibility(View.VISIBLE);
                        }
                        break;
                    case "districtname" :
                        districtname = spinner.getSelectedItem().toString();
                        if (adslocCode==0||adslocCode==1||adslocCode==3) {
                            s_taluka.setVisibility(View.VISIBLE);
                            populateSpinner(s_taluka, "Taluk");
                        }
                        break;

                    case "Taluk":
                        taluk = spinner.getSelectedItem().toString();
                        if (adslocCode==0||adslocCode==1) {
                            L_getAreaLayout.setVisibility(View.VISIBLE);
                        }
                        break;

                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    public void getArea(View view){

        String url = baseurl + "getarea/statename="+statename+"&Districtname="+districtname+"&Taluk="+taluk;
        Log.d(TAG, "getArea: "+url);
        RequestQueue queue = Volley.newRequestQueue(PincodeAndStateSelection.this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // response
                        Log.d(TAG, " onResponse: " + response);
                        ArrayList<String> po = new ArrayList<>();
                        JSONArray pinArrays = stringToJsonArray(response);

                        for (int i =0;i <  pinArrays.length();i++){

                            try {
                                JSONObject  pincodes = pinArrays.getJSONObject(i);
                                po.add(pincodes.getString("officename"));
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                        Sarea.setVisibility(View.VISIBLE);
                        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(PincodeAndStateSelection.this,android.R.layout.simple_spinner_item, po);
                        spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); // The drop down vieww
                        Sarea.setAdapter(spinnerArrayAdapter);

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // error
                        Log.d(TAG, error.toString() + " onErrorResponse: " + error.getMessage());
                        //Log.d(error.toString()+" Error.Response ", error.getMessage());
                        //Log.d(error.toString()+" Error.Response ", error.getMessage());
                    }
                }
        );

        queue.add(stringRequest);
    }


    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    public void finish(View view) {
        Intent returnIntent = new Intent();
        setResult(RESULT_CANCELED,returnIntent);
        finish();
    }

    public void done(View view) {
        String result = "";
        String statename = s_state.getSelectedItem().toString();
        switch (adslocCode){
            case 9 : result = s_state.getSelectedItem().toString(); break;
            case 7 : result = s_regionname.getSelectedItem().toString(); break;
            case 5 : result = s_district.getSelectedItem().toString(); break;
            case 3 : result = s_taluka.getSelectedItem().toString(); break;
            case 1 :
            case 0 :
                if (L_pinDetails.getVisibility() == View.VISIBLE)
                     result = _postOffice.getSelectedItem().toString();
                else
                     result = Sarea.getSelectedItem().toString(); break;
        }


        Intent returnIntent = new Intent();
        returnIntent.putExtra("data",result);
        returnIntent.putExtra(STATE,statename);
        setResult(RESULT_OK,returnIntent);
        finish();
    }


    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
