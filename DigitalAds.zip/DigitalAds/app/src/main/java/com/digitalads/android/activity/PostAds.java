package com.digitalads.android.activity;

import android.app.DatePickerDialog;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.basgeekball.awesomevalidation.utility.RegexTemplate;
import com.digitalads.android.model.AddressModel;
import com.digitalads.android.utils.Constants;
import com.digitalads.android.utils.myTextChangeListener;
import com.digitalads.android.views.MyTextViewRegular;
import com.digitalads.android.R;
import com.digitalads.android.model.UserModel;
import com.facebook.drawee.view.SimpleDraweeView;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static com.digitalads.android.utils.Constants.ADDRESS;
import static com.digitalads.android.utils.Constants.ADSLOCATION;
import static com.digitalads.android.utils.Constants.CAPTION;
import static com.digitalads.android.utils.Constants.DETAILS;
import static com.digitalads.android.utils.Constants.ENDDATE;
import static com.digitalads.android.utils.Constants.HEADING;
import static com.digitalads.android.utils.Constants.LOCATIONTYPE;
import static com.digitalads.android.utils.Constants.LOCATION_SELECT_INTENT;
import static com.digitalads.android.utils.Constants.NAME;
import static com.digitalads.android.utils.Constants.PICK_IMAGE_MUTIPLE;
import static com.digitalads.android.utils.Constants.PICK_IMAGE_REQUEST;
import static com.digitalads.android.utils.Constants.POINTS;
import static com.digitalads.android.utils.Constants.POST_PIC;
import static com.digitalads.android.utils.Constants.PUUID;
import static com.digitalads.android.utils.Constants.RPV;
import static com.digitalads.android.utils.Constants.SAVEDVALUE;
import static com.digitalads.android.utils.Constants.STATE;
import static com.digitalads.android.utils.Constants.STRING;
import static com.digitalads.android.utils.Constants.ZERO;
import static com.digitalads.android.utils.Constants.baseurl;
import static com.digitalads.android.utils.Constants.readSavedPreference;
import static com.digitalads.android.utils.Utils.getImageString;
import static com.digitalads.android.utils.Utils.saveContent;
import static com.digitalads.android.utils.Utils.shortUUID;
import static com.digitalads.android.utils.Utils.toggleVisibility;

public class PostAds extends AppCompatActivity {

    private AutoCompleteTextView _name,_headline,_details,_caption,_cpv,_budget;
    private MyTextViewRegular _imagename,
            T_heading,T_supporting_text,T_sub_heading,T_adslocation;
    private LinearLayout L_advanceoptionView;
    private MyTextViewRegular advanceoption,_end_date;
    private ImageButton ImageButtonExpand;
    private ImageView expand_button_ao;
    private RadioGroup radioGroup;
    private SimpleDraweeView postImage;
    private String imageString = "";
    private String TAG = "PostAds";
    private Spinner Sadslocation;
    private String state = SAVEDVALUE;

    
    int type = 1;
    private UserModel user;
    private AddressModel addressModel;
    //boolean ischangeLocation = false;
    String puuid = shortUUID();
    Calendar currentDate;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_ads);
        currentDate = Calendar.getInstance();
        user = new UserModel(this);
        String address = readSavedPreference(this,ADDRESS,STRING);
        if (address.equals(ZERO)){
            if (user.getAddress().equals(ZERO)){
                startActivity(new Intent(this,addressActivity.class));
            }else {
                postRequest();
            }
        }else
        initView();
    }

    private void initView() {
        addressModel = new AddressModel(this);
        //advance option
        advanceoption = findViewById(R.id.advanceoption);
        L_advanceoptionView = findViewById(R.id.advanceoptionView);
        expand_button_ao = findViewById(R.id.expand_button_ao);
        T_adslocation= findViewById(R.id.adslocation);
        L_advanceoptionView.setVisibility(View.GONE);
        Sadslocation = findViewById(R.id.Sadslocation);

        T_heading  = findViewById(R.id.heading);
        T_supporting_text = findViewById(R.id.supporting_text);
        T_sub_heading= findViewById(R.id.sub_heading);


        postImage = findViewById(R.id.postImage);


        ImageButtonExpand = findViewById(R.id.expand_button);
        ImageButtonExpand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(T_supporting_text.getVisibility()== View.VISIBLE)
                    ImageButtonExpand.setImageResource(R.drawable.ic_expand_more_black_24dp);
                else  ImageButtonExpand.setImageResource(R.drawable.ic_expand_less_black_24dp);
                {
                    toggleVisibility(T_supporting_text);
                }
               }
        });

        _name = findViewById(R.id.name);
        
        _headline = findViewById(R.id.headline);
        _details = findViewById(R.id.details);
        _caption = findViewById(R.id.caption);
        _end_date = findViewById(R.id.end_date);

        _cpv = findViewById(R.id.cpv);
        _budget = findViewById(R.id.budget);

        _headline.addTextChangedListener(new myTextChangeListener(T_heading));
        _details.addTextChangedListener(new myTextChangeListener(T_supporting_text));
        _caption.addTextChangedListener(new myTextChangeListener(T_sub_heading));

        radioGroup = findViewById(R.id.radioGroup);

        T_heading.setVisibility(View.GONE);
        T_supporting_text.setVisibility(View.GONE);
        ImageButtonExpand.setVisibility(View.GONE);

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, 7);
        String date = DateFormat.format("dd-MM-yyyy", cal).toString();
        _end_date.setText(MessageFormat.format("{0}",   date));

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch(checkedId)
                {
                    case R.id.rad_image:
                        T_heading.setVisibility(View.GONE);
                        ImageButtonExpand.setVisibility(View.GONE);
                        _headline.setVisibility(View.GONE);
                        _details.setVisibility(View.GONE);
                        T_supporting_text.setVisibility(View.GONE);
                        type = 1;
                        break;
                    case R.id.rad_headline:
                        ImageButtonExpand.setVisibility(View.GONE);
                        _headline.setVisibility(View.VISIBLE);
                        _details.setVisibility(View.GONE);
                        T_heading.setVisibility(View.VISIBLE);
                        T_supporting_text.setVisibility(View.GONE);
                        type = 2;
                        break;
                    case R.id.rad_details:
                        ImageButtonExpand.setVisibility(View.VISIBLE);
                        _headline.setVisibility(View.VISIBLE);
                        _details.setVisibility(View.VISIBLE);
                        T_heading.setVisibility(View.VISIBLE);
                        type = 3;
                        break;
                }
            }
        });

        advanceoption.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(L_advanceoptionView.getVisibility()== View.VISIBLE) {
                    expand_button_ao.setImageResource(R.drawable.ic_expand_more_black_24dp);
                    L_advanceoptionView.setVisibility(View.GONE);
                }
                else {
                    expand_button_ao.setImageResource(R.drawable.ic_expand_less_black_24dp);
                    L_advanceoptionView.setVisibility(View.VISIBLE);

                    Sadslocation.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                            Log.d(TAG, "onItemSelected: "+position);

                                Log.d(TAG, "onItemSelected: 2 "+position);
                                if (position == 1 || position == 3 || position == 5 || position == 7 || position == 9) {
                                    Log.d(TAG, "onItemSelected: 4 "+position);
                                    Intent intent = new Intent(PostAds.this, PincodeAndStateSelection.class);
                                    intent.putExtra("adslocCode", position);
                                    startActivityForResult(intent,LOCATION_SELECT_INTENT);
                                }else if (position == 0) {
                                    T_adslocation.setText(addressModel.getpostoffice());
                                }else if (position == 2) {
                                    T_adslocation.setText(addressModel.gettaluka());
                                }else if (position == 4) {
                                    T_adslocation.setText(addressModel.getdistrict());
                                }else if (position == 6) {
                                    T_adslocation.setText(addressModel.getcity());
                                }else if (position == 8) {
                                    T_adslocation.setText(addressModel.getstate());
                                }else if (position == 10) {
                                    T_adslocation.setText("India");
                                }



                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> parent) {

                        }
                    });
//                    Sadslocation.getAdapter().notify();
                }
            }
        });

    }

    public void done(View view) {
        if (imageString.equals("")) {
            Toast.makeText(this, R.string.imageNotSeleted, Toast.LENGTH_SHORT).show();
            return;
        }
        AwesomeValidation awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);
        switch (type) {
            case 3:
                awesomeValidation.addValidation(this, R.id.details, RegexTemplate.NOT_EMPTY, R.string.empty);
            case 2:

                awesomeValidation.addValidation(this, R.id.headline, RegexTemplate.NOT_EMPTY, R.string.empty);
            case 1:
                awesomeValidation.addValidation(this, R.id.name, RegexTemplate.NOT_EMPTY, R.string.empty);

                break;
        }
        if (awesomeValidation.validate()){
            final String headline = _headline.getText().toString();
            final String deatils  = _details.getText().toString();
            final String name  =  _name.getText().toString();
            final String caption  =  _caption.getText().toString();
            final String enddate  =  _end_date.getText().toString();

            final String cpv  =  _cpv.getText().toString();
            final String budget  =  _budget.getText().toString();
            final String locationtype  =  getType();
            final String[] adslocation = {T_adslocation.getText().toString()};

            //DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
            //Date startDate = df.parse(startDateString);

            Date date = null;
            try {
                date = new SimpleDateFormat("dd-MM-yyyy").parse(enddate);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            final String formattedDate = new SimpleDateFormat("yyyy-MM-dd").format(date);

            Log.d(TAG, "done: "+headline.concat(deatils).concat(name.concat(caption)));
            toggleVisibility(findViewById(R.id.progressBar));
            RequestQueue queue = Volley.newRequestQueue(this);
            //  String url ="http://192.168.56.1/digitalAds/homepage.json";
            // String url ="http://192.168.56.1:8000/api/v1/list";
            String url = baseurl + "postv";

            StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            // response
                            Log.d(TAG, " onResponse: " + response);
                            toggleVisibility(findViewById(R.id.progressBar));
                            /*saveContent(BusinessLP.this, BUSINESSLISTING, response);
                            isDonelisting = true;
                            if (isDoneprofile)
                                startActivity(new Intent(BusinessLP.this, HomeActivity.class));
                            else {
                                goneVisibility(businessListing);
                                goneVisibility(t_profileButton);
                                goneVisibility(t_listingButton);
                                businessProfiles.setVisibility(View.VISIBLE);
                            }*/
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            toggleVisibility(findViewById(R.id.progressBar));
                            // error
                            Log.d(TAG, error.toString() + " onErrorResponse: " + error);
                            //Log.d(error.toString()+" Error.Response ", error.getMessage());
                        }
                    }
            ) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    if (state.equals(SAVEDVALUE))
                        state = addressModel.getstate();
                    if (adslocation[0].length() < 2)
                        adslocation[0] = addressModel.getpostoffice();

                    switch (type) {
                        case 3: params.put(HEADING, headline);

                        case 2 : params.put(DETAILS, deatils);

                        case 1 :
                        params.put(NAME, name);
                        params.put(CAPTION, caption);
                        params.put(Constants.UUID, user.getUUID());
                        params.put(POST_PIC, imageString);
                        params.put(RPV, cpv);
                        params.put(POINTS, budget);
                        params.put(ENDDATE, formattedDate);
                        params.put(LOCATIONTYPE , locationtype);
                        params.put(ADSLOCATION, adslocation[0]);
                        params.put(PUUID,puuid );
                        params.put(STATE,state);
                        break;
                    }
                    Log.d(TAG, "getParams: "+user.getUUID());
                    Log.d(TAG, "getParams: "+name);
                    Log.d(TAG, "getParams: "+caption);
                    Log.d(TAG, "getParams: "+imageString);
                    Log.d(TAG, "getParams: "+cpv);
                    Log.d(TAG, "getParams: "+budget);
                    Log.d(TAG, "getParams: "+formattedDate);
                    Log.d(TAG, "getParams: "+locationtype);
                    Log.d(TAG, "getParams: "+adslocation[0]);

                    return params;
                }
            };

            queue.add(stringRequest);

        }
    }

    public void chooseImage(View view) {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_PICK);
        startActivityForResult(Intent.createChooser(intent, "Select Image"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Bitmap bitmap;
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri filePath = data.getData();

            try {
                //getting image from gallery
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                //Setting image to ImageView
                postImage.setImageURI(filePath);
                imageString = getImageString(bitmap);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (requestCode == PICK_IMAGE_MUTIPLE && resultCode == RESULT_OK && data != null) {
            String[] filePathColumn = { MediaStore.Images.Media.DATA };
            String imageEncoded;
            if (data.getClipData() != null) {
                ClipData mClipData = data.getClipData();
                ArrayList<Uri> mArrayUri = new ArrayList<Uri>();
                for (int i = 0; i < mClipData.getItemCount(); i++) {

                    ClipData.Item item = mClipData.getItemAt(i);
                    Uri filePath = item.getUri();
                    try {
                        //getting image from gallery
                        bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                        //Setting image to ImageView
                        View view = getLayoutInflater().inflate(R.layout.business_icon,null,false);
                        ImageView imageView = view.findViewById(R.id.imageViewItem);
                        imageView.setImageBitmap(bitmap);
                       // imageHolder.addView(view);
                        imageEncoded = getImageString(bitmap);
                        //imagesEncodedList.add(imageEncoded);

                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }
                Log.v("LOG_TAG", "Selected Images" + mArrayUri.size());
            }
            else if(data.getData()!=null){

                Uri filePath = data.getData();
                try {
                    //getting image from gallery
                    bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                    //Setting image to ImageView
                    View view = getLayoutInflater().inflate(R.layout.post_card_headline,null,false);
                    ImageView imageView = view.findViewById(R.id.imageViewItem);
                    imageView.setImageBitmap(bitmap);
                    //imageHolder.addView(imageView);
                    imageEncoded = getImageString(bitmap);
                    //imagesEncodedList.add(imageEncoded);

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }


            //images = new JSONArray(imagesEncodedList);
            //Log.d(TAG, "onActivityResult: "+images.length());
        }
        if(requestCode == LOCATION_SELECT_INTENT && resultCode == RESULT_OK && data != null){
            String selected = data.getStringExtra("data");
            state = data.getStringExtra(STATE);
            Log.d(TAG, "onActivityResult: "+data.getStringExtra("data"));
            T_adslocation.setText(selected);
        }
    }

    private Calendar date;
    public void date(View view) {

        date = Calendar.getInstance();

        DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
                date.set(year, monthOfYear, dayOfMonth);
                _end_date.setText(dayOfMonth+"-"+monthOfYear+"-"+year);

                //use this date as per your requirement
            }
        };
        DatePickerDialog datePickerDialog = new  DatePickerDialog(PostAds.this, dateSetListener, currentDate.get(Calendar.YEAR), currentDate.get(Calendar.MONTH),   currentDate.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
        datePickerDialog.show();
    }

    public  void postRequest() {
        Toast.makeText(this, "Loading Address", Toast.LENGTH_SHORT).show();
        toggleVisibility(findViewById(R.id.progressBar));
        RequestQueue queue = Volley.newRequestQueue(PostAds.this);
        //  String url ="http://192.168.56.1/digitalAds/homepage.json";
        String url =baseurl + "getaddress";
        //http://192.168.0.106/digitalAds/homepage.json
// Request a string response from the provided URL.
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("hello","hello");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String  response) {

                        saveContent(PostAds.this,ADDRESS,response);
                        toggleVisibility(findViewById(R.id.progressBar));
                        initView();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d(TAG, error.getMessage()+" onResponse: "+error.toString());
            }
        }){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String,String> headerParams = new HashMap<>();
                headerParams.put("Authorization","Bearer "+user.userToken());
                return headerParams;
            }
        } ;

// Add the request to the RequestQueue.
        queue.add(stringRequest);


    }

    public String getType(){

        switch(Sadslocation.getSelectedItemPosition()){
            case 0:
            case 1: return "area";
            case 2 :
            case 3 : return "taluka";
            case 4:
            case 5: return "district";
            case 6 :
            case 7 : return "city";
            case 8 :
            case 9 : return "state";
            case 10 : return "country";
            default: return  "area";
        }
    }
}
