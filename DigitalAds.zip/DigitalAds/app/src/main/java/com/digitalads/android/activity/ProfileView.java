package com.digitalads.android.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.digitalads.android.R;
import com.digitalads.android.model.UserModel;
import com.digitalads.android.views.MyTextViewRegular;

import static com.digitalads.android.utils.Constants.SAVEDVALUE;
import static com.digitalads.android.utils.Constants.USERDATA;
import static com.digitalads.android.utils.Utils.getView;
import static com.digitalads.android.utils.Utils.saveContent;
import static com.digitalads.android.utils.Utils.savetoShared;
import static com.digitalads.android.utils.Utils.toggleVisibility;

public class ProfileView extends AppCompatActivity {

    LinearLayout infoHolder;

    private MyTextViewRegular infotype,T_like,T_share,T_reviews,T_name;

    private UserModel userModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_view);

        initView();
    }

    private void initView() {
        userModel = new UserModel(this,"{}");
        infoHolder = findViewById(R.id.infoHolder);
        T_like = findViewById(R.id.like);
        T_share = findViewById(R.id.share);
        T_reviews = findViewById(R.id.reviews);
        T_name = findViewById(R.id.name);

        T_name.setText(userModel.getname());
        T_like.setText(userModel.getlikes());
        T_share.setText(userModel.getshares());
        T_reviews.setText(userModel.getreviews());
        generalinfo();

    }

    private void generalinfo() {
        View view = LayoutInflater.from(this).inflate(R.layout.details_holder,null,false);
        infotype = view.findViewById(R.id.infotype);
        final ImageView expand_button_personal = view.findViewById(R.id.expand_button_personal);
        final LinearLayout detailsHolder = view.findViewById(R.id.detailsHolder);
        infotype.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               expand(expand_button_personal,detailsHolder);
            }
        });

      expand_button_personal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               expand(expand_button_personal,detailsHolder);
            }
        });


        detailsHolder.addView(getView(this,"Email",userModel.getEmail()));
        detailsHolder.addView(getView(this,"Phone",userModel.getPhone()));
        detailsHolder.addView(getView(this,"DOB",userModel.getDob()));
        detailsHolder.addView(getView(this,"Created",userModel.getcreatedDate()));
        detailsHolder.addView(getView(this,"Last Update",userModel.getupdateddDate()));

        infoHolder.addView(view);
    }

    private void expand(ImageView expand_button_personal, LinearLayout detailsHolder) {
        if(detailsHolder.getVisibility() == View.VISIBLE) {
            expand_button_personal.setImageResource(R.drawable.ic_expand_less_black_24dp);
            detailsHolder.setVisibility(View.GONE);
        } else {
            expand_button_personal.setImageResource(R.drawable.ic_expand_more_black_24dp);
            detailsHolder.setVisibility(View.VISIBLE);
        }
    }


    public void logout(View view) {
        savetoShared(this).edit().putString(USERDATA,SAVEDVALUE).apply();
        startActivity(new Intent(this,RegLoginActivity.class));
    }
}
