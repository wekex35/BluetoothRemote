package com.digitalads.android.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.basgeekball.awesomevalidation.utility.RegexTemplate;
import com.digitalads.android.R;
import com.digitalads.android.model.UserModel;
import com.digitalads.android.utils.Utils;
import com.facebook.drawee.backends.pipeline.Fresco;
import com.scottyab.showhidepasswordedittext.ShowHidePasswordEditText;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import static com.digitalads.android.utils.Constants.SAVEDVALUE;
import static com.digitalads.android.utils.Constants.USERDATA;
import static com.digitalads.android.utils.Constants.baseurl;
import static com.digitalads.android.utils.Constants.jsonObjectreader;
import static com.digitalads.android.utils.Constants.jsonobject;
import static com.digitalads.android.utils.Constants.jsonobjectByName;
import static com.digitalads.android.utils.Utils.getSavedContent;
import static com.digitalads.android.utils.Utils.postRequest;
import static com.digitalads.android.utils.Utils.saveContent;
import static com.digitalads.android.utils.Utils.toggleVisibility;

public class RegLoginActivity extends AppCompatActivity {

    String TAG = "RegLoginActivity";
    private AutoCompleteTextView userId,phoneET,dobET,emailET,_name;
    private ShowHidePasswordEditText password,confirm_password;
    private  Button signin;
    private AwesomeValidation awesomeValidation;
    private RelativeLayout progressBAr;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Fresco.initialize(this);
        setContentView(R.layout.activity_reg_login);
        if (!getSavedContent(this,USERDATA).equals(SAVEDVALUE)){
            startActivity(new Intent(this, HomePage.class));
        }
        //postRequest();
    }

    public void showLoingAlyout(View view) {
        view.setVisibility(View.VISIBLE);
        findViewById(R.id.loginLayout).setVisibility(View.VISIBLE);
        initLogin();
    }

    private void initLogin() {
         userId = findViewById(R.id.userid);
         password = findViewById(R.id.password);
         signin = findViewById(R.id.signIn);
         progressBAr = findViewById(R.id.progressBar);
    }

    public void signIn(View view) {
        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);


        final String email = userId.getText().toString();
        final String pass = password.getText().toString();

        awesomeValidation.addValidation(this, R.id.userid, RegexTemplate.NOT_EMPTY, R.string.userid);
        awesomeValidation.addValidation(this, R.id.password, RegexTemplate.NOT_EMPTY, R.string.userid);


        if (awesomeValidation.validate()) {
            toggleVisibility(progressBAr);
            RequestQueue queue = Volley.newRequestQueue(this);

            String url = baseurl+"login";

            StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            // response
                            if (response.contains("error")){
                                Toast.makeText(RegLoginActivity.this, jsonObjectreader(response,"msg"), Toast.LENGTH_SHORT).show();
                            }
                            else
                            {
                                Log.d(TAG, " onResponse: " + response);
                            saveContent(RegLoginActivity.this, USERDATA, response);
                            UserModel user = new UserModel(RegLoginActivity.this);
                            if (user.getAddress().equals("0"))
                                startActivity(new Intent(RegLoginActivity.this, addressActivity.class));
                            else
                                home(progressBAr);
                        }
                            toggleVisibility(progressBAr);
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            // error
                            toggleVisibility(progressBAr);
                            Log.d(TAG, error.toString() + " onErrorResponse: " + error.getMessage());
                            //Log.d(error.toString()+" Error.Response ", error.getMessage());
                        }
                    }
            ) {


                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("email", email);
                    params.put("password", pass);

                    return params;
                }
            };

            queue.add(stringRequest);
        }


    }

    public void showSignuplyout(View view) {
        setContentView(R.layout.reg_layout);
       // findViewById(R.id.loginLayout).setVisibility(View.VISIBLE);
        initSignUp();
    }

    private void initSignUp() {
        emailET = findViewById(R.id.email);
        _name = findViewById(R.id.name);
        phoneET = findViewById(R.id.phone);
        dobET = findViewById(R.id.dob);
        password = findViewById(R.id.password);
        confirm_password = findViewById(R.id.confirm_password);
        signin = findViewById(R.id.signIn);
        progressBAr = findViewById(R.id.progressBar);
    }

    public void signUp(View view) {
        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);

        final String email = emailET.getText().toString();
        final String name = _name.getText().toString();
        final String phone = phoneET.getText().toString();
        final String dob = dobET.getText().toString();
        final String pass = password.getText().toString();
        final String cpass = password.getText().toString();
        Log.d(TAG, email + " signIn: " + pass);




        awesomeValidation.addValidation(this, R.id.name, "[a-zA-Z\\s]+", R.string.nameerror);
        awesomeValidation.addValidation(this, R.id.phone, RegexTemplate.NOT_EMPTY, R.string.mobileerror);
        awesomeValidation.addValidation(this, R.id.phone, "(^\\+\\d+)?[0-9\\s()-]*", R.string.mobileerror);
        awesomeValidation.addValidation(this, R.id.password, RegexTemplate.NOT_EMPTY, R.string.errpassword);
        awesomeValidation.addValidation(this, R.id.confirm_password, R.id.password, R.string.err_password_confirmation);



        if (awesomeValidation.validate() && phone.length()==10) {
            toggleVisibility(progressBAr);
            RequestQueue queue = Volley.newRequestQueue(this);
            //  String url ="http://192.168.56.1/digitalAds/homepage.json";
            // String url ="http://192.168.56.1:8000/api/v1/list";
            String url = baseurl+"register";
            final JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("data", "sssssshello");
            } catch (JSONException e) {
                e.printStackTrace();
            }
            StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            // response
                            Log.d(TAG, " onResponse: " + response);

                            if (response.contains("error")){

                               String toast = "";
                                JSONObject jsonObject1 = jsonobjectByName(response,"msg");
                                Iterator<String> iter = jsonObject1.keys();
                                while (iter.hasNext()) {
                                    String key = iter.next();

                                    try {
                                        String value = "";
                                        JSONArray valueArray = jsonObject1.getJSONArray(key);
                                        for (int i = 0; i < valueArray.length();i++){
                                            value += valueArray.getString(i);
                                        }
                                        toast += key+" : \n"+value+"\n";
                                    } catch (JSONException e) {
                                        // Something went wrong!
                                    }
                                }
                                Toast.makeText(RegLoginActivity.this, toast, Toast.LENGTH_SHORT).show();
                            }
                            else
                            {
                                Log.d(TAG, " onResponse: " + response);
                                //postRequest(RegLoginActivity.this,"getUser",USERDATA);
                                   saveContent(RegLoginActivity.this, USERDATA, response);
                                    postRequest(RegLoginActivity.this,"getUser",USERDATA);
                                    startActivity(new Intent(RegLoginActivity.this, addressActivity.class));
                                    home(progressBAr);
                            }
                            toggleVisibility(progressBAr);

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            toggleVisibility(progressBAr);
                            // error
                            Log.d(TAG, error.toString() + " onErrorResponse: " + error.getMessage());
                            //Log.d(error.toString()+" Error.Response ", error.getMessage());
                        }
                    }
            ) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("email", email);
                    params.put("name", name);
                    params.put("phone", phone);
                    params.put("dob", dob);
                    params.put("password", pass);
                    params.put("c_password", cpass);

                    return params;
                }
            };
            /*stringRequest.setRetryPolicy(new RetryPolicy() {
                @Override
                public int getCurrentTimeout() {
                    return 50000;
                }

                @Override
                public int getCurrentRetryCount() {
                    return 50000;
                }

                @Override
                public void retry(VolleyError error) throws VolleyError {

                }
            });*/

// Add the request to the RequestQueue.
            queue.add(stringRequest);


        }else{
            if (phone.length()==10){
                Toast.makeText(this, "Please Enter "+R.string.mobileerror, Toast.LENGTH_SHORT).show();

            }
        }
    }

    public void addSigninLayouyt(View view) {
        setContentView(R.layout.activity_reg_login);
    }

    public void home(View view) {
        Utils.taketoHome(this);
    }


}
