package com.digitalads.android.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.webkit.WebView;

import com.digitalads.android.R;

import static com.digitalads.android.utils.Constants.WEBURL;
import static com.digitalads.android.utils.Constants.baseWebUrl;

public class WebViewActivity extends AppCompatActivity {
    private String TAG = "WebViewActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view);
        WebView webView = findViewById(R.id.webView);
        String webUrl = baseWebUrl + getIntent().getStringExtra(WEBURL);
        Log.d(TAG, "onCreate: "+webUrl);
        webView.loadUrl(webUrl);
    }
}
