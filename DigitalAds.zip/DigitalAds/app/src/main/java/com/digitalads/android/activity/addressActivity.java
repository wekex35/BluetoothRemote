package com.digitalads.android.activity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.basgeekball.awesomevalidation.utility.RegexTemplate;
import com.digitalads.android.HomeActivity;
import com.digitalads.android.R;
import com.digitalads.android.model.UserModel;
import com.digitalads.android.utils.Utils;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static com.digitalads.android.utils.Constants.ACCOUNT_TYPE;
import static com.digitalads.android.utils.Constants.ADDRESS;
import static com.digitalads.android.utils.Constants.AREA;
import static com.digitalads.android.utils.Constants.BUILDING;
import static com.digitalads.android.utils.Constants.BUSINESSNAME;
import static com.digitalads.android.utils.Constants.CITY;
import static com.digitalads.android.utils.Constants.DISTRICT;
import static com.digitalads.android.utils.Constants.LANDMARK;
import static com.digitalads.android.utils.Constants.PINCODE;
import static com.digitalads.android.utils.Constants.POSTOFFICE;
import static com.digitalads.android.utils.Constants.STATE;
import static com.digitalads.android.utils.Constants.STREET;
import static com.digitalads.android.utils.Constants.TALUKA;
import static com.digitalads.android.utils.Constants.UUID;
import static com.digitalads.android.utils.Constants.baseurl;
import static com.digitalads.android.utils.Utils.fn_getlocation;
import static com.digitalads.android.utils.Utils.saveContent;
import static com.digitalads.android.utils.Utils.stringToJsonArray;
import static com.digitalads.android.utils.Utils.toggleVisibility;

public class addressActivity extends AppCompatActivity {
    Spinner _account_type,_postOffice;
    AutoCompleteTextView _businessName,_address,_building,_street,_landmark
            ,_pincode,_state,_district,_taluka,_city,_latLong,_area;
    LinearLayout L_deliveryAdds,L_poffice,L_pinDetails;
    RelativeLayout progressBAr;
    String TAG = "addressActivity";
    private ArrayList<JSONObject> pincodeDetails;
    private AwesomeValidation awesomeValidation;
    private UserModel user;
    private boolean isBussiness = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.address_layout);
        user = new UserModel(this);

        initdata();
    }

    private void initdata() {
        //Layout
        L_deliveryAdds = findViewById(R.id.deliveryAdds);
        L_pinDetails = findViewById(R.id.pinDetails);
        L_poffice = findViewById(R.id.poffice);
        progressBAr = findViewById(R.id.progressBar);

        //Inputs
                //Spinner
        _account_type = findViewById(R.id.accountType);
        _postOffice = findViewById(R.id.postOffice);

        //Business and Full addressActivity
        _businessName = findViewById(R.id.businessName);
        _address = findViewById(R.id.address);
        _building = findViewById(R.id.building);
        _street = findViewById(R.id.street);
        _landmark = findViewById(R.id.landmark);
        _latLong = findViewById(R.id.latLong);

        //short Address
        _pincode = findViewById(R.id.pincode);
        _state = findViewById(R.id.state);
        _district = findViewById(R.id.district);
        _taluka = findViewById(R.id.taluka);
        _city = findViewById(R.id.city);
        _area = findViewById(R.id.area);







        _account_type.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);

                awesomeValidation.addValidation(addressActivity.this, R.id.pincode, RegexTemplate.NOT_EMPTY, R.string.empty);
                awesomeValidation.addValidation(addressActivity.this, R.id.state, RegexTemplate.NOT_EMPTY, R.string.empty);
                awesomeValidation.addValidation(addressActivity.this, R.id.district, RegexTemplate.NOT_EMPTY, R.string.empty);
                awesomeValidation.addValidation(addressActivity.this, R.id.taluka, RegexTemplate.NOT_EMPTY, R.string.empty);
                awesomeValidation.addValidation(addressActivity.this, R.id.city, RegexTemplate.NOT_EMPTY, R.string.empty);

                Toast.makeText(addressActivity.this, "Data "+ _account_type.getSelectedItem().toString(), Toast.LENGTH_SHORT).show();
                if (_account_type.getSelectedItem().toString().equals("Business")){
                    L_deliveryAdds.setVisibility(View.VISIBLE);
                    awesomeValidation.addValidation(addressActivity.this, R.id.businessName, RegexTemplate.NOT_EMPTY, R.string.empty);
                    awesomeValidation.addValidation(addressActivity.this, R.id.address, RegexTemplate.NOT_EMPTY, R.string.empty);
                    isBussiness = true;
                }else if(_account_type.getSelectedItem().toString().equals("Full Address")){
                    L_deliveryAdds.setVisibility(View.VISIBLE);
                    _businessName.setVisibility(View.GONE);
                    isBussiness = false;
                    awesomeValidation.addValidation(addressActivity.this, R.id.address, RegexTemplate.NOT_EMPTY, R.string.empty);
                }else {
                    isBussiness = false;
                    L_deliveryAdds.setVisibility(View.GONE);
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        _pincode.setOnFocusChangeListener(new View.OnFocusChangeListener() {

            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                pincodeDetails = new ArrayList<>();
                if (!_pincode.hasFocus()) {
                    if (_pincode.length() != 6)
                        Toast.makeText(addressActivity.this, "Pin", Toast.LENGTH_SHORT).show();
                    else {
                        String url = "http://192.168.252.2/DigiApi/public/api/v1/getdata/"+_pincode.getText().toString();
                        RequestQueue queue = Volley.newRequestQueue(addressActivity.this);
                        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                                new Response.Listener<String>() {
                                    @Override
                                    public void onResponse(String response) {
                                        // response
                                        Log.d(TAG, " onResponse: " + response);
                                        ArrayList<String> po = new ArrayList<>();
                                        JSONArray pinArrays = stringToJsonArray(response);

                                        for (int i =0;i <  pinArrays.length();i++){

                                            try {
                                                JSONObject  pincodes = pinArrays.getJSONObject(i);
                                                pincodeDetails.add(pincodes);

                                                po.add(pincodes.getString("officename")
                                                        .replace("B.O","")
                                                        .replace("S.O","")
                                                        .replace("H.O","")
                                                );


                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            }

                                        }
                                        L_poffice.setVisibility(View.VISIBLE);
                                        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(addressActivity.this,android.R.layout.simple_spinner_item, po);
                                        spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); // The drop down vieww
                                        _postOffice.setAdapter(spinnerArrayAdapter);
                                    }
                                },
                                new Response.ErrorListener() {
                                    @Override
                                    public void onErrorResponse(VolleyError error) {
                                        // error
                                        Log.d(TAG, error.toString() + " onErrorResponse: " + error.getMessage());
                                        //Log.d(error.toString()+" Error.Response ", error.getMessage());
                                        //Log.d(error.toString()+" Error.Response ", error.getMessage());
                                    }
                                }
                        );

                    queue.add(stringRequest);
                }
                    }
                _postOffice.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    JSONObject selctedOfficeObject = pincodeDetails.get(position);
                        L_pinDetails.setVisibility(View.VISIBLE);
                        try {
                            _state.setText(selctedOfficeObject.getString("statename"));
                            _taluka.setText(selctedOfficeObject.getString("Taluk"));
                            _district.setText(selctedOfficeObject.getString("Districtname"));
                            _city.setText(selctedOfficeObject.getString("regionname"));
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });
                }

        });
    }

    public void home(View view) {
        Utils.taketoHome(this);
    }

    public void done(View view) {

        if (awesomeValidation.validate()) {
            final JSONObject dataToSend = new JSONObject();
            try {
                Log.d(TAG, "done: "+user.getUUID());
                dataToSend.put(UUID, user.getUUID());
                dataToSend.put(ACCOUNT_TYPE, _account_type.getSelectedItem().toString());
                dataToSend.put(BUSINESSNAME, _businessName.getText().toString());
                dataToSend.put(ADDRESS, _address.getText().toString());
                dataToSend.put(BUILDING, _building.getText().toString());
                dataToSend.put(STREET, _street.getText().toString());
                dataToSend.put(LANDMARK, _landmark.getText().toString());
                dataToSend.put(PINCODE, _pincode.getText().toString());
                dataToSend.put(STATE, _state.getText().toString());
                dataToSend.put(DISTRICT, _district.getText().toString());
                dataToSend.put(TALUKA, _taluka.getText().toString());
                dataToSend.put(CITY, _city.getText().toString());
                dataToSend.put(AREA, _area.getText().toString());
                dataToSend.put(POSTOFFICE, _postOffice.getSelectedItem().toString());

                toggleVisibility(progressBAr);
                RequestQueue queue = Volley.newRequestQueue(this);
                //  String url ="http://192.168.56.1/digitalAds/homepage.json";
                // String url ="http://192.168.56.1:8000/api/v1/list";
                String url = baseurl+"address";
                StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                // response
                                Log.d(TAG, " onResponse: " + response);
                                toggleVisibility(progressBAr);
                                saveContent(addressActivity.this,ADDRESS,response);
                                if (response.contains("success")) {
                                    if (isBussiness)
                                        startActivity(new Intent(addressActivity.this,BusinessLP.class));
                                    else
                                        startActivity(new Intent(addressActivity.this, HomeActivity.class));
                                }else {

                                }

                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                toggleVisibility(progressBAr);
                                // error
                                Log.d(TAG, error.toString() + " onErrorResponse: " + error.getMessage());
                                //Log.d(error.toString()+" Error.Response ", error.getMessage());
                            }
                        }
                ) {
                   /*@Override
                    public Map<String, String> getHeaders() throws AuthFailureError {
                        Map<String, String> params = new HashMap<>();
                        params.put("Content-Type", "application/json; charset=UTF-8");
                        params.put("token",user.userToken());
                        return params;
                    }*/
                    @Override
                    protected Map<String, String> getParams() {
                        Map<String, String> params = new HashMap<>();
                        Log.d(TAG, "getParams: "+dataToSend.toString());
                        params.put("data", dataToSend.toString());

                        return params;
                    }
                };
           
                queue.add(stringRequest);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }
    public String  startgps() {
        // first check for permissions
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.INTERNET}
                        ,10);
            }
            return "0,0";
        }
        // this code won't execute IF permissions are not allowed, because in the line above there is return statement.
        return fn_getlocation(this);

    }
}
