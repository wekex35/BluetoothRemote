package com.digitalads.android.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.digitalads.android.R;
import com.digitalads.android.activity.BusinessLP;

import java.util.ArrayList;

import static com.digitalads.android.activity.BusinessLP.keywordsList;

public class MutliSelectAdapter extends ArrayAdapter<String> {

    private  LayoutInflater mInflater;
    private  Context mContext;
    private ArrayList<String> items;

    public MutliSelectAdapter(Context context,
                               ArrayList<String> array) {
        super(context, 0, array);

        mContext = context;
        mInflater = LayoutInflater.from(context);
        items = array;
    }
    @Override
    public View getDropDownView(int position, @Nullable View convertView,
                                @NonNull ViewGroup parent) {
        return createItemView(position, convertView, parent);
    }

    @Override
    public @NonNull View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return createItemView(position, convertView, parent);
    }

    private View createItemView(int position, View convertView, ViewGroup parent){
        final View view = mInflater.inflate(R.layout.item_multiselectvextview, parent, false);

        final TextView Tvitem =view.findViewById(R.id.item);
        Tvitem.setText(items.get(position));
        final String slectedItem = Tvitem.getText().toString();
        Log.d(keywordsList+"MultiAdap", "out: ");
        Tvitem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(keywordsList+"MultiAdap", "onClick: ");


                if(keywordsList.contains(slectedItem)) {
                    Tvitem.setSelected(false);
                    keywordsList.remove(slectedItem);
                    Log.d("MultiAdap", "onClick: itemUNSelect"+keywordsList);

                }else{
                    Tvitem.setSelected(true);
                    keywordsList.add(slectedItem);
                    Log.d("MultiAdap", "onClick: itemSelect"+keywordsList);
                }

                ((BusinessLP)mContext).setItemTokeywords();
            }
        });
        if(keywordsList.contains(slectedItem))
            Tvitem.setSelected(true);
        else Tvitem.setSelected(false);



        return view;
    }
}
