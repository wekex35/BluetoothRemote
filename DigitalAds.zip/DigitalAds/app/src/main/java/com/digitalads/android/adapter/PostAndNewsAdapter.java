package com.digitalads.android.adapter;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.digitalads.android.R;
import com.digitalads.android.utils.Utils;
import com.facebook.drawee.view.SimpleDraweeView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import static com.digitalads.android.utils.Constants.getScreenHeight;
import static com.digitalads.android.utils.Constants.jsonObjectreader;
import static com.digitalads.android.utils.Utils.getScreenWidth;
import static com.digitalads.android.utils.Utils.readJsonString;


/**
 * Created by Alessandro Barreto on 23/06/2016.
 */
public class PostAndNewsAdapter extends RecyclerView.Adapter<PostAndNewsAdapter.MyChatViewHolder> {

    private int type;
    private String TAG ="messageAdapter";

    ArrayList<JSONObject> homeJson;
    Activity activity;

    public PostAndNewsAdapter(Activity mainActivity, ArrayList<JSONObject> pos) {


        activity = mainActivity;
        homeJson = pos;
    }

    @Override
    public MyChatViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.post_card_article,parent,false);
            return new MyChatViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyChatViewHolder viewHolder, int position) {

        JSONObject model = homeJson.get(position);
        viewHolder.setTitle(Utils.readJsonString(model,"name"));
        viewHolder.setContent(Utils.readJsonArray(model,"content"));
        /*   JSONObject recieved = jsonobjectByName(model.toString(), "msginfo");
        String sender = jsonobjectByNameJSONOBJECT(recieved,"sender");
        String status = jsonobjectByNameJSONOBJECT(recieved,"status");
        final String timeStamp = jsonobjectByNameJSONOBJECT(recieved,"timeStamp");




        model = jsonobjectByName(model.toString(),"securedmsg");
        Log.d(TAG, "onBindViewHolder: "+model.toString());
     if (model.has("replyto")) {
            String replyto = jsonobjectByNameJSONOBJECT(model, "replyto");
            Log.d(TAG, "onBindViewHolder: "+replyto);
            if (!replyto.equals("0")) {
                viewHolder.replyHolder.removeAllViews();
                viewHolder.replyHolder.addView(getView(replyto));
            }else{
               /// viewHolder.replyHolder.addView(null);
                viewHolder.replyHolder.setVisibility(View.GONE);
            }
        }
       // viewHolder.setIvUser(myChatmodel.getUserModel().getPhoto_profile());
        viewHolder.status.setImageDrawable(picsatus(Integer.parseInt(status)));
        viewHolder.setTxtMessage(jsonobjectByNameJSONOBJECT(model, "message"));
        viewHolder.setTvTimestamp(jsonobjectByNameJSONOBJECT(model, "timeStamp"));
        viewHolder.tvIsLocation(View.GONE);
        if (!jsonobjectByNameJSONOBJECT(model, "file").equals("0")){
            viewHolder.tvIsLocation(View.GONE);
            viewHolder.setIvChatPhoto(jsonobjectByNameJSONOBJECT(model, "file"),jsonobjectByNameJSONOBJECT(model, "name"));
        }else if(!jsonobjectByNameJSONOBJECT(model, "mapModel").equals("0")){
            viewHolder.setIvChatPhoto(com.game.ballBreaker.util.Util.local(myChatmodel.getMapModel().getLatitude(),myChatmodel.getMapModel().getLongitude()), jsonobjectByNameJSONOBJECT(model, "name"));
            viewHolder.tvIsLocation(View.VISIBLE);
        }
        viewHolder.contentMessageChat.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                ((MainActivity)activity).replyTo(timeStamp);
                Toast.makeText(activity, "Long Pressed"+timeStamp, Toast.LENGTH_SHORT).show();
                return false;
            }

        });*/
    }

    @Override
    public int getItemCount() {
        Log.d(TAG, "getItemCount: "+homeJson.size());
        return homeJson.size();
    }

    public class MyChatViewHolder extends RecyclerView.ViewHolder {

        TextView title;

        View hscroll;
        int width;// = ll.getWidth();

        public MyChatViewHolder(View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.title);

            hscroll = itemView.findViewById(R.id.hscroll);
            width = hscroll.getWidth();
            /*
            tvTimestamp = (TextView)itemView.findViewById(R.id.timestamp);
            txtMessage = (EmojiconTextView)itemView.findViewById(R.id.txtMessage);
            status = itemView.findViewById(R.id.status);
            tvLocation = (TextView)itemView.findViewById(R.id.tvLocation);
            ivChatPhoto = (ImageView)itemView.findViewById(R.id.img_chat);
            ivUser = (ImageView)itemView.findViewById(R.id.ivUserChat);
            messageView = itemView.findViewById(R.id.messageView);
            contentMessageChat = itemView.findViewById(R.id.contentMessageChat);
            replyHolder = itemView.findViewById(R.id.replyHolder);
            */

        }

        public void setTitle(String title) {
            this.title.setText(title);
        }

        public void setContent(JSONArray array) {

                LinearLayout ll = (LinearLayout) this.hscroll;
                ll.removeAllViews();

                for (int i = 0; i < array.length(); i++) {
                    try {
                        View view = getView(getItemViewType(), array.getJSONObject(i));
                        LinearLayout.LayoutParams param = new LinearLayout.LayoutParams(
                                /*width*/ getScreenWidth()-10,
                                /*height*/ (getScreenHeight()/3)-(getScreenHeight()/10)
                                /*weight*/
                        );
                        view.setLayoutParams(param);
                        ll.addView(view);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }

    }

    private View getView(int itemViewType, JSONObject object) {
        View view = LayoutInflater.from(activity).inflate(R.layout.item_card_vertical,null,false);
        SimpleDraweeView simpleDraweeView = view.findViewById(R.id.imageView);
        //Glide.with(activity).load("http://goo.gl/gEgYUd").into(simpleDraweeView);
        String img = readJsonString(object,"img");
        Log.d(TAG, "getView: "+img);
        simpleDraweeView.setImageURI(img);
        return view;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

}
