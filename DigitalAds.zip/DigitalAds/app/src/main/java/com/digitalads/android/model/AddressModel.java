package com.digitalads.android.model;

import android.content.Context;
import android.util.Log;

import org.json.JSONObject;

import static com.digitalads.android.utils.Constants.ADDRESS;
import static com.digitalads.android.utils.Constants.AREA;
import static com.digitalads.android.utils.Constants.BUILDING;
import static com.digitalads.android.utils.Constants.BUSSINESS_NAME;
import static com.digitalads.android.utils.Constants.CITY;
import static com.digitalads.android.utils.Constants.DISTRICT;
import static com.digitalads.android.utils.Constants.LANDMARK;
import static com.digitalads.android.utils.Constants.LON_LAT;
import static com.digitalads.android.utils.Constants.PINCODE;
import static com.digitalads.android.utils.Constants.POSTOFFICE;
import static com.digitalads.android.utils.Constants.SAVEDVALUE;
import static com.digitalads.android.utils.Constants.STATE;
import static com.digitalads.android.utils.Constants.STREET;
import static com.digitalads.android.utils.Constants.TALUKA;
import static com.digitalads.android.utils.Constants.UUID;
import static com.digitalads.android.utils.Constants.jsonobject;
import static com.digitalads.android.utils.Utils.getSavedContent;
import static com.digitalads.android.utils.Utils.readJsonString;

public class AddressModel {

    JSONObject jsonData;
    public AddressModel(Context context) {
        String TAG = "USERCLASS";
        String userDate = getSavedContent(context, ADDRESS);
        if (!userDate.equals(SAVEDVALUE)) {
            Log.d(TAG, "UserModel: ");
            jsonData = jsonobject(userDate);
//            categories = readJsonArray(userDataJSON,"catogeries");
        }
    }

    public String getpincode(){
        return readJsonString(jsonData, PINCODE );
    }
    public String getaddress(){
        return readJsonString(jsonData,  ADDRESS);
    }
    public String getbuilding(){
        return readJsonString(jsonData,  BUILDING);
    }
    public String getpostoffice(){
        return readJsonString(jsonData,  POSTOFFICE);
    }
    public String getstate(){
        return readJsonString(jsonData,  STATE);
    }
    public String getstreet(){
        return readJsonString(jsonData,  STREET);
    }
    public String getlandmark(){
        return readJsonString(jsonData,  LANDMARK);
    }
    public String getdistrict(){
        return readJsonString(jsonData,  DISTRICT);
    }
    public String gettaluka(){
        return readJsonString(jsonData,  TALUKA);
    }
    public String getcity(){
        return readJsonString(jsonData,  CITY);
    }
    public String getarea(){
        return readJsonString(jsonData,  AREA);
    }
    public String getlon_lat(){
        return readJsonString(jsonData,  LON_LAT);
    }
    public String getuuid(){
        return readJsonString(jsonData,  UUID);
    }
    public String getbussiness_name(){
        return readJsonString(jsonData,  BUSSINESS_NAME);
    }


}
