package com.digitalads.android.model;

import android.content.Context;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import static com.digitalads.android.utils.Constants.ADDRESS;
import static com.digitalads.android.utils.Constants.COMMENTS;
import static com.digitalads.android.utils.Constants.CREATED_AT;
import static com.digitalads.android.utils.Constants.DOB;
import static com.digitalads.android.utils.Constants.EMAIL;
import static com.digitalads.android.utils.Constants.LASTVISITED;
import static com.digitalads.android.utils.Constants.LIKES;
import static com.digitalads.android.utils.Constants.NAME;
import static com.digitalads.android.utils.Constants.PHONE;
import static com.digitalads.android.utils.Constants.SAVEDVALUE;
import static com.digitalads.android.utils.Constants.SHARES;
import static com.digitalads.android.utils.Constants.SUBSCRIPTIONS;
import static com.digitalads.android.utils.Constants.TOKEN;
import static com.digitalads.android.utils.Constants.UPDATED_AT;
import static com.digitalads.android.utils.Constants.USERDATA;
import static com.digitalads.android.utils.Constants.USER_TYPE;
import static com.digitalads.android.utils.Constants.UUID;
import static com.digitalads.android.utils.Constants.jsonobject;
import static com.digitalads.android.utils.Utils.getSavedContent;
import static com.digitalads.android.utils.Utils.readJsonObject;
import static com.digitalads.android.utils.Utils.readJsonString;

public class UserModel {

    JSONObject userJSON;
    JSONObject userActivityJSON;
    JSONArray categories;
    JSONObject userDataJSON;
    String Token;
    public UserModel(Context context) {
        String TAG = "USERCLASS";
        String userDate = getSavedContent(context,USERDATA);
        if (!userDate.equals(SAVEDVALUE)){
            String name = "bname";
            Log.d(TAG, "UserModel: ");
            userDataJSON = jsonobject(userDate);
            userJSON = readJsonObject(userDataJSON,"user");
//            categories = readJsonArray(userDataJSON,"catogeries");
    }
   }
    public UserModel(Context context,String Profiles) {
        String TAG = "USERCLASS";
        String userDate = getSavedContent(context,USERDATA);
        if (!userDate.equals(SAVEDVALUE)){
            String name = "bname";
            Log.d(TAG, "UserModel: ");
            userDataJSON = jsonobject(userDate);
            userJSON = readJsonObject(userDataJSON,"user");
//            categories = readJsonArray(userDataJSON,"catogeries");
        }

            //userDataJSON = jsonobject(Profiles);
            //userJSON = readJsonObject(userDataJSON,"user");
            //userActivityJSON = readJsonObject(userDataJSON,"users_activity");
//            categories = readJsonArray(userDataJSON,"catogeries");

   }

   public String getname(){
       return readJsonString(userJSON,NAME);
   }
   public String getEmail(){
       return readJsonString(userJSON,EMAIL);
   }
   public boolean isEmailVarified(){
       if(readJsonString(userJSON,"token")==null)
           return false;
            else return true;
   }
   public String getDob(){
       return readJsonString(userJSON,DOB);
   }
   public String getPhone(){
       return readJsonString(userJSON,PHONE);
   }
   public String getUUID(){
       return readJsonString(userJSON,UUID);
   }
   public String getUSERType(){
       return readJsonString(userJSON,USER_TYPE);
   }
   public String getcreatedDate(){
       return readJsonString(userJSON,CREATED_AT);
   }
   public String getupdateddDate(){
       return readJsonString(userJSON,UPDATED_AT);
   }
   public String getAddress(){
       return readJsonString(userJSON,ADDRESS);
   }


   public String userToken(){
       return readJsonString(readJsonObject(userDataJSON,"success"),TOKEN);
   }

    public String getlikes(){ return "100";//readJsonString(userActivityJSON, LIKES);
    }
    public String getshares(){ return "100";//readJsonString(userActivityJSON, SHARES);
    }
    public String getreviews(){ return "100";//readJsonString(userActivityJSON, COMMENTS);
    }
    public String getsubscriptions(){ return "100";//readJsonString(userActivityJSON, SUBSCRIPTIONS);
    }
    public String getlastvisited (){ return "100";//readJsonString(userActivityJSON, LASTVISITED);
    }








}
