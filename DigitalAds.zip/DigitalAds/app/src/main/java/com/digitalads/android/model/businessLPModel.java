package com.digitalads.android.model;

import android.content.Context;

import org.json.JSONObject;

import static com.digitalads.android.utils.Constants.CATEGORIES;
import static com.digitalads.android.utils.Constants.COMMENTS;
import static com.digitalads.android.utils.Constants.CREATED_AT;
import static com.digitalads.android.utils.Constants.DETAILS;
import static com.digitalads.android.utils.Constants.EMAIL;
import static com.digitalads.android.utils.Constants.IMAGES;
import static com.digitalads.android.utils.Constants.KEYWORDS;
import static com.digitalads.android.utils.Constants.LIKES;
import static com.digitalads.android.utils.Constants.NAME;
import static com.digitalads.android.utils.Constants.PHONE;
import static com.digitalads.android.utils.Constants.POST;
import static com.digitalads.android.utils.Constants.PROFILEPIC;
import static com.digitalads.android.utils.Constants.RATINGS;
import static com.digitalads.android.utils.Constants.SHARES;
import static com.digitalads.android.utils.Constants.SUB_CATEGORIES;
import static com.digitalads.android.utils.Constants.UPDATED_AT;
import static com.digitalads.android.utils.Constants.UUID;
import static com.digitalads.android.utils.Constants.WEBSITE;
import static com.digitalads.android.utils.Constants.jsonobject;
import static com.digitalads.android.utils.Utils.readJsonString;

public class businessLPModel {

    JSONObject jsonData;
    public businessLPModel(Context context, String read) {

            jsonData = jsonobject(read);
//            categories = readJsonArray(userDataJSON,"catogeries");

    }

    public String getuuid(){ return readJsonString(jsonData, UUID);}
    public String getemail(){ return readJsonString(jsonData, EMAIL);}
    public String getwebsite(){ return readJsonString(jsonData, WEBSITE);}
    public String getphone(){ return readJsonString(jsonData, PHONE);}
    public String getdetails(){ return readJsonString(jsonData, DETAILS);}
    public String getimages(){ return readJsonString(jsonData, IMAGES);}
    public String getname(){ return readJsonString(jsonData, NAME);}
    public String getprofilePic(){ return readJsonString(jsonData, PROFILEPIC);}
    public String getcategories(){ return readJsonString(jsonData, CATEGORIES);}
    public String getsub_categories(){ return readJsonString(jsonData, SUB_CATEGORIES );}
    public String getkeywords(){ return readJsonString(jsonData, KEYWORDS);}
    public String getcreated_at(){ return readJsonString(jsonData, CREATED_AT);}
    public String getupdated_at(){ return readJsonString(jsonData, UPDATED_AT);}
    public String getlikes(){ return readJsonString(jsonData, LIKES);}
    public String getshares(){ return readJsonString(jsonData, SHARES);}
    public String getcomments(){ return readJsonString(jsonData, COMMENTS);}
    public String getratings(){ return readJsonString(jsonData, RATINGS);}
    public String getpost(){ return readJsonString(jsonData, POST);}


}
