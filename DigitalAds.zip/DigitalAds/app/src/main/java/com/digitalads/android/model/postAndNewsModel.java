package com.digitalads.android.model;

import android.content.Context;

import org.json.JSONObject;

import static com.digitalads.android.utils.Constants.CAPTION;
import static com.digitalads.android.utils.Constants.COMMENTS;
import static com.digitalads.android.utils.Constants.CREATED_AT;
import static com.digitalads.android.utils.Constants.DETAILS;
import static com.digitalads.android.utils.Constants.ENDDATE;
import static com.digitalads.android.utils.Constants.HEADING;
import static com.digitalads.android.utils.Constants.LIKES;
import static com.digitalads.android.utils.Constants.NAME;
import static com.digitalads.android.utils.Constants.POINTS;
import static com.digitalads.android.utils.Constants.POST_PIC;
import static com.digitalads.android.utils.Constants.PUUID;
import static com.digitalads.android.utils.Constants.RPV;
import static com.digitalads.android.utils.Constants.SHARES;
import static com.digitalads.android.utils.Constants.UPDATED_AT;
import static com.digitalads.android.utils.Constants.UUID;
import static com.digitalads.android.utils.Constants.jsonobject;
import static com.digitalads.android.utils.Utils.readJsonString;

public class postAndNewsModel {

    JSONObject jsonData;
    public postAndNewsModel(Context context, String read) {
        String TAG = "USERCLASS";

            jsonData = jsonobject(read);
//            categories = readJsonArray(userDataJSON,"catogeries");

    }

    public String  getuuid(){ return readJsonString(jsonData, UUID);}
    public String  getpuuid(){ return readJsonString(jsonData, PUUID);}
    public String  getname(){ return readJsonString(jsonData, NAME);}
    public String  getheading(){ return readJsonString(jsonData, HEADING);}
    public String  getcaption(){ return readJsonString(jsonData, CAPTION);}
    public String  getpostPic(){ return readJsonString(jsonData, POST_PIC);}
    public String  getdetails(){ return readJsonString(jsonData, DETAILS);}
    public String  getcreated_at(){ return readJsonString(jsonData, CREATED_AT);}
    public String  getupdated_at(){ return readJsonString(jsonData, UPDATED_AT);}
    public String  getenddate(){ return readJsonString(jsonData, ENDDATE);}
    public String  getrpv(){ return readJsonString(jsonData, RPV);}
    public String  getpoints(){ return readJsonString(jsonData, POINTS);}
    public String  getlikes(){ return readJsonString(jsonData, LIKES);}
    public String  getshares(){ return readJsonString(jsonData, SHARES);}
    public String  getcomments(){ return readJsonString(jsonData, COMMENTS);}

}
