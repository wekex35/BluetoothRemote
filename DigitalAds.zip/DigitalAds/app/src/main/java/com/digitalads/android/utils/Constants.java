package com.digitalads.android.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.text.format.DateUtils;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.UUID;

public class Constants {
    public static int LOCATION_SELECT_INTENT = 3;
    public static int REQUEST_INVITE = 4;

    public static String ZERO = "0";
    public static String SAVEDVALUE = "NA";
    public static String WEBURL = "url";
    public static final String SHARED_PREFERENCES_NAME = "digitalsAds";
    public static final String USERDATA = "usersdate";


    public static final String  UUID = "uuid";
    public static final String  ACCOUNT_TYPE = "account_type";
    public static final String  FIREBASETOKEN = "firebasetoken";
    public static final String  POSTOFFICE = "postoffice";
    public static final String  BUSINESSNAME = "business_name";
    public static final String  ADDRESS = "address";
    public static final String  TOKEN = "token";
    public static final String  USER_TYPE = "user_type";
    public static final String  BUILDING  = "building";
    public static final String  STREET = "street";
    public static final String  LANDMARK = "landmark";
    public static final String  PINCODE = "pincode";
    public static final String  STATE = "state";
    public static final String  DISTRICT = "district";
    public static final String  TALUKA = "taluka";
    public static final String  CITY = "city";
    public static final String  AREA = "area";
    public static final String  BUSSINESS_NAME = "bussiness_name";
    public static final String  LON_LAT = "lon_lat";


    public static final String NAME = "name";
    public static final String PROFILEPIC = "profilepic";
    public static final String CATEGORIES = "categories";
    public static final String SUB_CATEGORIES = "sub_categories";
    public static final String KEYWORDS = "keywords";
    public static final String CREATED_AT = "created_at";
    public static final String UPDATED_AT = "updated_at";
    public static final String LIKES = "likes";
    public static final String SHARES = "shares";
    public static final String COMMENTS = "comments";
    public static final String RATINGS = "ratings";
    public static final String POST = "post";
    public static final String PROFILE_PIC = "profilepic";
    public static final String SUBSCRIPTIONS = "subscriptions";
    public static final String LASTVISITED = "lastvisited";



    public static String PUUID = "puuid";
    public static String ENDDATE = "enddate";
    public static String RPV = "rpv";
    public static String POINTS = "points";
    public static String LOCATIONTYPE  = "locationtype";
    public static String ADSLOCATION   = "adslocation";

    public static String EMAIL = "email";
    public static String WEBSITE = "website";
    public static String PHONE = "phone";

    public static String DETAILS = "details";
    public static String IMAGES = "images";

    public static String CAPTION = "caption";
    public static String POST_PIC = "postPic";
    public static String HEADING = "heading";

    public static String BUSINESSPROFILE = "businessprofile";
    public static String BUSINESSLISTING = "businesslisting";



    public static final int PICK_IMAGE_MUTIPLE = 2;
    public static final int PICK_IMAGE_REQUEST = 1;


    public static final String baseurl = "http://192.168.252.2/DigiApi/public/api/v1/";
    public static final String baseWebUrl = "http://192.168.252.2/DigiApi/public/";
    public static final String PROFILE_NAME = "profie_name";
    public static final String TOPIC = "topic";

    public static final String INT = "int";
    public static final String STRING = "string";
    public static final String BOOLEAN = "boolean";




    public static boolean FIRSTROOM;



    private static final String TAG = "ConstantsCLass";


    public static final String ROOMS = "rooms";
    public static final String EMPTY = "empty";
    public static final String PASSWORD = "pass";
    public static final String USER_ID = "UID";
    public static final String fNAME = "fname";
    public static final String LNAME = "lname";
    public static final String TYPE = "type";


    //DATABASE CONSTANTS
    public static final String TIMESTAMP = "timestamp";
    public static final String STATUS = "status";
    public static final String RECIEVER = "reciever";
    public static final String SENDER = "sender";
    public static final String SENDTO = "sendto";
    public static final String TABLE_MESSAGE = "table_message";
    public static final String TABLE_USER = "table_user";
    public static final String CONTACT_NO = "mobile";
    public static final String MESSAGE = "message";


    public static final String DOB = "dob";
    public static Drawable dia_backdrawable;
    public static String gradename;
    public static String PowerDnoR = "";
    public static RelativeLayout dia_cardRoom;
    public static String SCORE = "score";
    public static String mytopic;
    public static String sendto;
    public static String myname;

    public static final String KEY_ID = "id";
    public static final String KEY_NAME = "name";
    public static final String KEY_PATH = "path";


    /*public static DatabaseHandler dbHandler(Context context){
        return new DatabaseHandler(context);
    }*/



    public static SharedPreferences sharedPreferences;
    public static final String GET_DEVICE = "getdevices";
    public static final String MQTT_BROKER_URL = "tcp://3.94.64.196:1883";
    public static String STATUS_TOPIC;// = "status/"+mytopic;
    public static String PROFILE_TOPIC;// = "status/"+mytopic;
    public static final String  PROFILE_UPDATED = "profile_updated";// = "status/"+mytopic;
    public static final String SUSCRIBE_TOPIC = "u/c14ecd7a-7869-4c5f-bdae-c93f107b5edf/sub";
    public static final String    CLIENT_ID = "c14ecd7a-7869-4c5f-bdae-c93f107b5edf";
    public static final String    PRE_CLIENT_ID = "pre_client_id";
    //public static final String  clientId   = UUID.randomUUID().toString();
   // public static MqttAndroidClient GeneralpahoMqttClient;
    public static String mobNo;

    //color picker
    public static int blue;
    public static int green;
    public static int red;
    public static float brightness;
    public static int warm_white;
    public static int white;
    public static final int colorpickerActivity = 2;

    //
    public static String getTimeStamp() {
        return Calendar.getInstance().getTime().getTime()+"";
    }

    public static int getScreenWidth() {
        return Resources.getSystem().getDisplayMetrics().widthPixels;
    }

    public static int getScreenHeight() {
        return Resources.getSystem().getDisplayMetrics().heightPixels;
    }

    public static final String SMARTCONFIGPASSWORD = "smartpassword";

    public static SharedPreferences savetoShared(Context baseContext) {
        return baseContext.getSharedPreferences(SHARED_PREFERENCES_NAME, Context.MODE_PRIVATE);
    }


    /*public static MqttAndroidClient getClientConnection(Context context) {
        String user = savetoShared(context).getString(Constants.USER_ID, "0");
        String pass = savetoShared(context).getString(Constants.PASSWORD, "0");
        return new PahoMqttClient().getMqttClientAuthenticate(context, Constants.MQTT_BROKER_URL, user, pass);
    }*/



    public static String jsonObjectreader(String json, String name) {
        try {
            JSONObject jsonObject = new JSONObject(json);
            return jsonObject.get(name).toString();
        } catch (JSONException e) {
            e.printStackTrace();
            return "error";
        }

    }

    public static JSONObject jsonobject(String json) {
        try {
            return new JSONObject(json);
        } catch (JSONException e) {
            e.printStackTrace();
            Log.d("contsnt", "jsonobject: " + e.getMessage());
            return null;
        }

    }

    public static JSONObject jsonobjectByName(String json, String name) {
        try {
            JSONObject jsonObject = new JSONObject(json);
            return jsonObject.getJSONObject(name);
        } catch (JSONException e) {
            e.printStackTrace();
            Log.d("contsnt", "jsonobject: " + e.getMessage());
            return null;
        }

    }
    
    public static String jsonobjectByNameJSONOBJECT(JSONObject jsonObject, String name) {
        try {
            return jsonObject.getString(name);
        } catch (JSONException e) {
            e.printStackTrace();
            Log.d("contsnt", "jsonobject: " + e.getMessage());
            return null;
        }

    }
    /*
     @Override
    public int getItemViewType(int position) {
        JSONObject model = jsonobject(messages.get(position));
        if (!jsonobjectByNameJSONOBJECT(model, "mapModel").equals("")){
            if (jsonobjectByNameJSONOBJECT(jsonobjectByName(model.toString(),"userInfo"),"name").equals(nameUser)){
                return RIGHT_MSG_IMG;
            }else{
                return LEFT_MSG_IMG;
            }
        }else if (!jsonobjectByNameJSONOBJECT(model, "file").equals("")){
            if (jsonobjectByNameJSONOBJECT(jsonobjectByName(model.toString(),"userInfo"),"name").equals(nameUser)){
                return RIGHT_MSG_IMG;
            }else{
                return LEFT_MSG_IMG;
            }
        }else if (jsonobjectByNameJSONOBJECT(jsonobjectByName(model.toString(),"userInfo"),"name").equals(nameUser)){
            return RIGHT_MSG;
        }else{
            return LEFT_MSG;
        }
    }
    */

    public static JSONArray getJsonArray(JSONObject jsonObject, String name) {
        try {
            return jsonObject.getJSONArray(name);
        } catch (JSONException e) {
            e.printStackTrace();
            Log.d(TAG, "getJsonArray: " + e.getMessage());
        }
        return null;
    }




    public static void getProgressBar(ProgressBar progressBar){
        if (progressBar.getVisibility() == View.VISIBLE){
            progressBar.setVisibility(View.GONE);
        }else {
            progressBar.setVisibility(View.GONE);
        }
    }

    public static ArrayList<String> createdate(int start, int end) {
        ArrayList<String> list = new ArrayList<String>();
        for (int i = start; i <= end; i++) {
            if (i < 10) {
                list.add("0" + i);
            } else {
                list.add("" + i);
            }
        }
        return list;
    }

    public static ArrayList<String> createtime(int no) {
        ArrayList<String> list = new ArrayList<String>();
        for (int i = 0; i < no; i++) {
            if (i < 10) {
                list.add("0" + i);
            } else {
                list.add("" + i);
            }
        }
        return list;
    }

    public static ArrayList<String> createMinutes() {
        ArrayList<String> list = new ArrayList<String>();
        for (int i = 0; i < 60; i++) {
            if (i < 10) {
                list.add("0" + i);
            } else {
                list.add("" + i);
            }
        }
        return list;
    }


    public static JSONObject stringToJsonObject(String msg) {
        try {
            return new JSONObject(msg);
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void jsonObjectPut(JSONObject jsonObject1, String key, String value) {
        try {
            jsonObject1.put(key,value);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public static String userJSon(String myname, String image_url, String mytopic) {

        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("name",myname);
            jsonObject.put("image_url",image_url);
            jsonObject.put("id",mytopic);
            return jsonObject.toString();
        } catch (JSONException e) {
            e.printStackTrace();
            JSONObject jsonObject = new JSONObject();
            return jsonObject.toString();
        }
    }

  public static String messageInfoJSon(String timeStamp,String sender, String reciever, int status) {

        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("sender",sender);
            jsonObject.put("reciever",reciever);
            jsonObject.put("timeStamp",timeStamp);
            jsonObject.put("status",status);
            return jsonObject.toString();
        } catch (JSONException e) {
            e.printStackTrace();
            JSONObject jsonObject = new JSONObject();
            return jsonObject.toString();
        }
    }


    public static String securemessage(String userInfo, String message, String timeStamp, String file, String mapModel, String replyto) {
        try {
            JSONObject jsonObject = new JSONObject();
            JSONObject jsonObjectUSER = new JSONObject(userInfo);
            jsonObject.put("userInfo",jsonObjectUSER);
            jsonObject.put("message",message);
            jsonObject.put("timeStamp",timeStamp);
            jsonObject.put("file",file);
            jsonObject.put("mapModel",mapModel);
            jsonObject.put("replyto",replyto);
            return jsonObject.toString();
        } catch (JSONException e) {
            e.printStackTrace();
            JSONObject jsonObject = new JSONObject();
            return jsonObject.toString();
        }
    }



    public static String setStatus(String onOff){
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("message",onOff);
            jsonObject.put("sender",mytopic);
            jsonObject.put("timestamp",getTimeStamp());
            jsonObject.put(TYPE,"status");
            return jsonObject.toString();
        } catch (JSONException e) {
            e.printStackTrace();
            JSONObject jsonObject = new JSONObject();
            return jsonObject.toString();
        }

    }

    public static String setProfile(String profile_pic){
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(NAME ,myname);
            jsonObject.put(CONTACT_NO,mytopic);
            jsonObject.put(PROFILE_PIC,profile_pic);
            jsonObject.put(TYPE,"profile");
            return jsonObject.toString();
        } catch (JSONException e) {
            e.printStackTrace();
            JSONObject jsonObject = new JSONObject();
            return jsonObject.toString();
        }

    }

    public static String getProfilePic(Context activity){

        AssetManager assetManager = activity.getAssets();
        InputStream istr = null;
        try {
            istr = assetManager.open("avtar.jpg");
        } catch (IOException e) {
            e.printStackTrace();
        }
        Bitmap bm = BitmapFactory.decodeStream(istr);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.JPEG, 50 , baos);
        byte[] b = baos.toByteArray();
        String imageString = Base64.encodeToString(b, Base64.DEFAULT);
        return imageString;
    }
    public static String pubMessage(String msginfo,String securedmsg){
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("msginfo",jsonobject(msginfo));
            jsonObject.put("securedmsg",securedmsg);
            return jsonObject.toString();
        } catch (JSONException e) {
            e.printStackTrace();
            JSONObject jsonObject = new JSONObject();
            return jsonObject.toString();
        }
    }

    public static String acknowledge(String msg,String msginfo){
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(msginfo,jsonobject(msg));
            return jsonObject.toString();
        } catch (JSONException e) {
            e.printStackTrace();
            JSONObject jsonObject = new JSONObject();
            return jsonObject.toString();
        }
    }




    public static String readSavedPreference(Context context,String key,String type){
        String value = "0";
        switch (type){
            case INT : value = String.valueOf(savetoShared(context).getInt(key,0));break;
            case STRING : value = savetoShared(context).getString(key,"0");break;
            case BOOLEAN : value = String.valueOf(savetoShared(context).getBoolean(key,false));break;
        }

        return value;
    }
    public static String getName(Context context){
        return readSavedPreference(context,PROFILE_NAME,STRING);
    }
    public static String getTopic(Context context){
        return readSavedPreference(context,TOPIC,STRING);
    }


    public static CharSequence converteTimestamp(String mileSegundos){
        return DateUtils.getRelativeTimeSpanString(Long.parseLong(mileSegundos),System.currentTimeMillis(), DateUtils.SECOND_IN_MILLIS);
    }

/*
    public static String decrpt(String data,String Key){
        return Encoder.BuilderAES()
                .message(data)
                .method(AES.Method.AES_CBC_PKCS5PADDING)
                .key(Key)
                .keySize(AES.Key.SIZE_128)
                .iVector("test vector")
                .decrypt();
    }

    public static void updatestatus(String onOFF) {
        String unsecured = setStatus(onOFF);
        String secured = securedMsg(unsecured,mytopic);
        Log.d(TAG, "updateprofile: "+secured);
        String msg = "{\"isOnline\":\""+secured+"\"}";//Constants.acknowledge(secured,"profile");
        Log.d(TAG, "updateprofile: "+msg);
        try {
            new PahoMqttClient().publishMessagewithRetain(Constants.GeneralpahoMqttClient,msg,0,STATUS_TOPIC);
        } catch (MqttException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    public static String setWill(String onOFF) {
        String unsecured = setStatus(onOFF);
        String secured = securedMsg(unsecured,mytopic);
        Log.d(TAG, "updateprofile: "+secured);
        String msg = "{\"isOnline\":\""+secured+"\"}";//Constants.acknowledge(secured,"profile");
        return msg;

    }

    public static void adtotheContactTable(JSONObject msginfo,Context context) {
        new DatabaseHandler(context).addContact(jsonobjectByNameJSONOBJECT(msginfo,"sender"));
    }

        public static String securedMsg(String unsecuredmsg,String key) {
        return  Encoder.BuilderAES()
                .message(unsecuredmsg)
                .method(AES.Method.AES_CBC_PKCS5PADDING)
                .key(key)
                .keySize(AES.Key.SIZE_128)
                .iVector("test vector")
                .encrypt();
    }
*/
}