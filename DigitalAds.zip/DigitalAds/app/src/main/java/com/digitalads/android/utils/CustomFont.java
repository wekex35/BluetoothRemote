package com.digitalads.android.utils;

import android.content.res.AssetManager;
import android.graphics.Typeface;

public class CustomFont {
    public static final Typeface setFontRegular(AssetManager assetManager) {
        return Typeface.createFromAsset(assetManager, "fonts/anko-personal-use.regular.otf");
    }

    public static final Typeface setFontRegularThin(AssetManager assetManager) {
        return Typeface.createFromAsset(assetManager, "fonts/anko-personal-use.regular.otf");
    }
}
