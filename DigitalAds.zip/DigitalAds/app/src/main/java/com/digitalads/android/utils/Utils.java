package com.digitalads.android.utils;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.location.LocationManager;
import android.net.Uri;
import android.support.customtabs.CustomTabsIntent;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;

import android.location.Location;
import android.location.LocationListener;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.digitalads.android.HomeActivity;
import com.digitalads.android.R;
import com.digitalads.android.activity.HomePage;
import com.digitalads.android.activity.PostNews;
import com.digitalads.android.activity.RegLoginActivity;
import com.digitalads.android.activity.WebViewActivity;
import com.digitalads.android.model.UserModel;
import com.digitalads.android.views.MyTextViewRegular;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static android.content.Context.LOCATION_SERVICE;
import static com.android.volley.VolleyLog.TAG;
import static com.digitalads.android.utils.Constants.SAVEDVALUE;
import static com.digitalads.android.utils.Constants.SHARED_PREFERENCES_NAME;
import static com.digitalads.android.utils.Constants.USERDATA;
import static com.digitalads.android.utils.Constants.WEBURL;
import static com.digitalads.android.utils.Constants.baseurl;

public class Utils {


    public static String readJsonString(JSONObject object, String name) {
        try { return object.getString(name);
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
    }
    public static int readJsonInt(JSONObject object, String name) {
        try { return object.getInt(name);
        } catch (JSONException e) {
            e.printStackTrace();
            return 0;
        }
    }
    public static JSONObject readJsonObject(JSONObject object, String name) {
        try { return object.getJSONObject(name);
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static JSONArray readJsonArray(JSONObject object, String name) {
        try { return object.getJSONArray(name);
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static JSONArray stringToJsonArray(String string) {
        try { return new JSONArray(string);
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
    }


    public static int getScreenWidth() {
        return Resources.getSystem().getDisplayMetrics().widthPixels;
    }

    public static int getScreenHeight() {
        return Resources.getSystem().getDisplayMetrics().heightPixels;
    }

    public static String loadFileAsset(Context context,String file) {
        String string = null;
        try {
            InputStream is = context.getAssets().open(file);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            string = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return string;
    }

    public static void toggleVisibility(View view) {
       if (view.getVisibility()== View.VISIBLE){
           view.setVisibility(View.GONE);
       }else {
           view.setVisibility(View.VISIBLE);
       }
    }

    public static void goneVisibility(View view) {
       if (view.getVisibility()== View.VISIBLE){
           view.setVisibility(View.GONE);
       }
    }

    public static void taketoHome(Context context) {
        context.startActivity(new Intent(context, HomeActivity.class));
    }

    public static SharedPreferences savetoShared(Context baseContext) {
        return baseContext.getSharedPreferences(SHARED_PREFERENCES_NAME, Context.MODE_PRIVATE);
    }

    public static void saveContent(Context context, String key, String value) {
        savetoShared(context).edit().putString(key,value).apply();
    }

    public static String getSavedContent(Context context, String key) {
        return savetoShared(context).getString(key,SAVEDVALUE);
    }

    @SuppressLint("MissingPermission")
    public static String fn_getlocation(Context context){
        LocationManager locationManager;
        LocationListener listener;
        boolean isGPSEnable = false;
        boolean isNetworkEnable = false;
        double latitude = 0,longitude = 0;
        locationManager = (LocationManager)context.getSystemService(LOCATION_SERVICE);
        isGPSEnable = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        isNetworkEnable = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        Location location;

        if (!isGPSEnable && !isNetworkEnable){

        }else {

            if (isNetworkEnable){
                location = null;
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,1000,0, (LocationListener) context);
                if (locationManager!=null){
                    location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                    if (location!=null){

                        Log.e("latitude",location.getLatitude()+"");
                        Log.e("longitude",location.getLongitude()+"");

                        latitude = location.getLatitude();
                        longitude = location.getLongitude();
                       // fn_update(location);
                    }
                }

            }


            if (isGPSEnable){
                location = null;
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,1000,0, (LocationListener) context);
                if (locationManager!=null){
                    location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                    if (location!=null){
                        Log.e("latitude",location.getLatitude()+"");
                        Log.e("longitude",location.getLongitude()+"");
                        latitude = location.getLatitude();
                        longitude = location.getLongitude();
                       // fn_update(location);
                    }
                }
            }


        }
        return String.valueOf(longitude)+','+ String.valueOf(latitude);

    }

    public static void postRequest(final Activity activity, String getUrl, final String savedAt) {
    final String token = new UserModel(activity).userToken();
        Log.d(TAG, "postRequest: "+token);
    RequestQueue queue = Volley.newRequestQueue(activity);
    //  String url ="http://192.168.56.1/digitalAds/homepage.json";
    String url =baseurl + getUrl;
    //http://192.168.0.106/digitalAds/homepage.json
// Request a string response from the provided URL.
    JSONObject jsonObject = new JSONObject();
        try {
        jsonObject.put("hello","hello");
    } catch (JSONException e) {
        e.printStackTrace();
    }
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                @Override
                public void onResponse(String  response) {
                    if (!response.contains("error"))
                        saveContent(activity,savedAt,Constants.jsonObjectreader(response,"success"));
                }
            }, new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            Log.d(TAG, error.getMessage()+" onResponse: "+error.toString());
        }
    }){
        @Override
        public Map<String, String> getHeaders() throws AuthFailureError {
            Map<String,String> headerParams = new HashMap<>();
            headerParams.put("Authorization","Bearer "+token);
            return headerParams;
        }
    } ;

// Add the request to the RequestQueue.
        queue.add(stringRequest);


}


   /* private void postRequest(Activity activity) {


// ...

// Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(activity);
        //  String url ="http://192.168.56.1/digitalAds/homepage.json";
        String url ="http://192.168.0.106:8000/api/v1/login";
//http://192.168.0.106/digitalAds/homepage.json
// Request a string response from the provided URL.
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("hello","hello");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST,url,jsonObject,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        return response;
                    }


                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d(TAG, error.getMessage()+" onResponse: "+error.toString());
            }
        }) ;

// Add the request to the RequestQueue.
        queue.add(stringRequest);


    }*/
   /*public static boolean isValidMobile(String phone) {
       return android.util.Patterns.PHONE.matcher(phone).matches();
   }
    public static boolean isValidEmail(String email) {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    public static boolean isValidPassword(String pass1) {
       if (!pass1.isEmpty()){
           if (pass1.length()<8)

       }
        return Patterns..matcher(email).matches();
    }

    public static boolean matchPassword(String pass1,String Pass2) {

        return Patterns..matcher(email).matches();
    }*/

   public static void customTabs(Context context,String url){
       Uri uri = Uri.parse(url);
       CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
       builder.setToolbarColor(context.getResources().getColor(R.color.ColorPrimary));
       CustomTabsIntent customTabsIntent = builder.build();
       customTabsIntent.launchUrl(context,uri);
   }
   public static void webview(Context context,String url){
       Intent intent  = new Intent(context, WebViewActivity.class);
       intent.putExtra(WEBURL,url);
       context.startActivity(intent);
   }

   public static String getImageString(Bitmap bitmap){
       ByteArrayOutputStream baos = new ByteArrayOutputStream();
       bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
       byte[] imageBytes = baos.toByteArray();
       return Base64.encodeToString(imageBytes, Base64.DEFAULT);

   }

    public static String shortUUID() {
        UUID uuid = UUID.randomUUID();
        long l = ByteBuffer.wrap(uuid.toString().getBytes()).getLong();
        return Long.toString(l, Character.MAX_RADIX);
    }

    public static View getView(Context context ,String key, String value) {
        TextView T_key,T_value;
        View view = LayoutInflater.from(context).inflate(R.layout.key_value,null,false);
        T_key = view.findViewById(R.id.key);
        T_value = view.findViewById(R.id.value);

        T_key.setText(key);
        T_value.setText(value);

        return view;

    }
}
