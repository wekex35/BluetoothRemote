package com.digitalads.android.utils;

import android.text.Editable;
import android.text.TextWatcher;

import com.digitalads.android.views.MyTextViewRegular;

public class myTextChangeListener implements TextWatcher {
    MyTextViewRegular textViewRegular ;
    public myTextChangeListener(MyTextViewRegular view) {
        textViewRegular = view;
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        textViewRegular.setText(s);
    }

    @Override
    public void afterTextChanged(Editable s) {

    }
}
