package com.digitalads.android.views;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.widget.TextView;

import com.digitalads.android.utils.CustomFont;


@SuppressLint("AppCompatCustomView")
public class MyTextViewRegular extends TextView {
    public MyTextViewRegular(Context context) {
        super(context);
        init();
    }

    public MyTextViewRegular(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init();
    }

    public MyTextViewRegular(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init();
    }

    public void init() {
        setTypeface(CustomFont.setFontRegular(getContext().getAssets()));
    }

    /*public void setText(String str) {
        if (TextUtils.isEmpty(str)) {
            str = "";
        }
        setText(str);
    }*/
}
